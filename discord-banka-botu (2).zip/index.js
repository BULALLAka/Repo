/**
 * Discord Banka Botu
 * Global ekonomi sistemi
 * 
 * Ozellikler:
 * - Hesap yonetimi
 * - Para yatirma/cekme/transfer
 * - Vadeli hesap
 * - Kredi sistemi
 * - Temerrut yonetimi
 * - Fatura sistemi
 * - Level/XP sistemi
 * - Admin paneli
 */

require("dotenv").config();
const {
	Client,
	GatewayIntentBits,
	Partials,
	Collection,
	EmbedBuilder,
} = require("discord.js");
const mongoose = require("mongoose");
const config = require("./src/config/config");
const { startScheduler } = require("./src/utils/scheduler");

// Komut dosyalari
const accountCommands = require("./src/commands/account");
const bankingCommands = require("./src/commands/banking");
const workCommands = require("./src/commands/work");
const savingsCommands = require("./src/commands/savings");
const creditCommands = require("./src/commands/credit");
const defaultCommands = require("./src/commands/default");
const billsCommands = require("./src/commands/bills");
const leaderboardCommands = require("./src/commands/leaderboard");
const adminCommands = require("./src/commands/admin");
const helpCommands = require("./src/commands/help");

// Discord client
const client = new Client({
	intents: [
		GatewayIntentBits.Guilds,
		GatewayIntentBits.GuildMessages,
		GatewayIntentBits.MessageContent,
		GatewayIntentBits.GuildMembers,
	],
	partials: [Partials.Channel, Partials.Message],
});

// Komutlari birlestir
const commands = {
	...accountCommands,
	...bankingCommands,
	...workCommands,
	...savingsCommands,
	...creditCommands,
	...defaultCommands,
	...billsCommands,
	...leaderboardCommands,
	...adminCommands,
	...helpCommands,
};

// Cooldown collection
const cooldowns = new Collection();

// MongoDB baglantisi
async function connectDatabase() {
	try {
		await mongoose.connect(process.env.MONGODB_URI, {
			maxPoolSize: 10,
			serverSelectionTimeoutMS: 5000,
			socketTimeoutMS: 45000,
		});
		console.log("[Database] MongoDB bagalntisi basarili!");
	} catch (error) {
		console.error("[Database] MongoDB baglanti hatasi:", error);
		process.exit(1);
	}
}

// MongoDB baglanti olaylari
mongoose.connection.on("disconnected", () => {
	console.log("[Database] MongoDB baglantisi kesildi. Yeniden baglaniliyor...");
	setTimeout(connectDatabase, 5000);
});

mongoose.connection.on("error", (error) => {
	console.error("[Database] MongoDB hatasi:", error);
});

// Bot hazir
client.once("ready", () => {
	console.log(`[Bot] ${client.user.tag} olarak giris yapildi!`);
	console.log(`[Bot] ${client.guilds.cache.size} sunucuda aktif`);

	// Durum ayarla
	client.user.setPresence({
		activities: [
			{
				name: "!yardim | Banka Botu",
				type: 3, // Watching
			},
		],
		status: "online",
	});

	// Zamanlanmis gorevleri baslat
	startScheduler();
});

// Mesaj olaylari
client.on("messageCreate", async (message) => {
	// Bot mesajlarini yoksay
	if (message.author.bot) return;

	// Prefix kontrolu
	if (!message.content.startsWith(config.prefix)) return;

	// Komutu ayikla
	const args = message.content.slice(config.prefix.length).trim().split(/ +/);
	const commandName = args.shift().toLowerCase();

	// Komut var mi kontrol et
	const command = commands[commandName];
	if (!command) return;

	// Cooldown kontrolu
	if (!cooldowns.has(commandName)) {
		cooldowns.set(commandName, new Collection());
	}

	const now = Date.now();
	const timestamps = cooldowns.get(commandName);
	const cooldownAmount = (config.cooldowns[commandName] || 3) * 1000;

	if (timestamps.has(message.author.id)) {
		const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

		if (now < expirationTime) {
			const timeLeft = (expirationTime - now) / 1000;
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.warning)
						.setDescription(
							`Bu komutu tekrar kullanmak icin **${timeLeft.toFixed(1)}** saniye beklemelisin.`,
						),
				],
			});
		}
	}

	timestamps.set(message.author.id, now);
	setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

	// Komutu calistir
	try {
		await command(message, args);
	} catch (error) {
		console.error(`[Komut Hatasi] ${commandName}:`, error);

		message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.error)
					.setTitle("Hata Olustu")
					.setDescription(
						"Komut calistirilirken bir hata olustu. Lutfen daha sonra tekrar deneyin.",
					),
			],
		});
	}
});

// Hata yakalama
process.on("unhandledRejection", (error) => {
	console.error("[Unhandled Rejection]", error);
});

process.on("uncaughtException", (error) => {
	console.error("[Uncaught Exception]", error);
});

// SIGTERM ve SIGINT yakalama (graceful shutdown)
process.on("SIGTERM", async () => {
	console.log("[Bot] SIGTERM sinyali alindi. Kapatiliyor...");
	await mongoose.connection.close();
	client.destroy();
	process.exit(0);
});

process.on("SIGINT", async () => {
	console.log("[Bot] SIGINT sinyali alindi. Kapatiliyor...");
	await mongoose.connection.close();
	client.destroy();
	process.exit(0);
});

// Botu baslat
async function startBot() {
	try {
		// Veritabanina baglan
		await connectDatabase();

		// Discord'a baglan
		await client.login(process.env.DISCORD_TOKEN);
	} catch (error) {
		console.error("[Bot] Baslama hatasi:", error);
		process.exit(1);
	}
}

startBot();
