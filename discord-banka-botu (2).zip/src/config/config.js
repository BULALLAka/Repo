/**
 * ========================================
 * BANKA BOTU KONFİGÜRASYON DOSYASI
 * ========================================
 * Tüm bot ayarları burada tanımlanır
 */

module.exports = {
    // Bot Prefix
    prefix: process.env.PREFIX || '!',
    
    // Admin Kullanıcı Adı
    adminUsername: process.env.ADMIN_USERNAME || 'ikashop1',
    
    // Embed Renkleri
    colors: {
        success: 0x00FF00,    // Yeşil
        error: 0xFF0000,      // Kırmızı
        warning: 0xFFFF00,    // Sarı
        info: 0x0099FF,       // Mavi
        gold: 0xFFD700,       // Altın
        bank: 0x2F3136,       // Koyu gri (banka teması)
        premium: 0x9B59B6     // Mor (premium)
    },
    
    // Para Birimi
    currency: {
        symbol: '💵',
        name: 'TL',
        format: (amount) => `${amount.toLocaleString('tr-TR')} TL`
    },
    
    // Meslekler ve Maaşları
    jobs: {
        'işsiz': { salary: 0, minLevel: 0, description: 'Henüz bir mesleğiniz yok' },
        'memur': { salary: 5000, minLevel: 1, description: 'Devlet memuru - Düşük ama güvenli gelir' },
        'esnaf': { salary: 7500, minLevel: 3, description: 'Küçük işletme sahibi' },
        'freelancer': { salary: 10000, minLevel: 5, description: 'Serbest çalışan - Esnek gelir' },
        'yazılımcı': { salary: 15000, minLevel: 8, description: 'Yazılım geliştirici - Yüksek talep' },
        'bankacı': { salary: 20000, minLevel: 12, description: 'Banka çalışanı - Finans uzmanı' },
        'yönetici': { salary: 30000, minLevel: 18, description: 'Üst düzey yönetici - En yüksek maaş' }
    },
    
    // Çalışma Sistemi
    work: {
        cooldown: 30 * 60 * 1000,        // 30 dakika (ms)
        baseEarning: 500,                 // Temel kazanç
        maxEarning: 2000,                 // Maksimum kazanç
        xpGain: 10                        // Kazanılan XP
    },
    
    // Maaş Sistemi
    salary: {
        cooldown: 24 * 60 * 60 * 1000,   // 24 saat (ms)
        defaultPenalty: 0.30              // Temerrüt kesintisi %30
    },
    
    // Transfer Sistemi
    transfer: {
        taxRate: 0.02,                    // Transfer vergisi %2
        dailyLimit: 500000,               // Günlük limit
        hourlyLimit: 100000,              // Saatlik limit
        minAmount: 100,                   // Minimum transfer
        xpGain: 5                         // Kazanılan XP
    },
    
    // Vadeli Hesap
    savings: {
        periods: {
            7: { rate: 0.05, name: '7 Günlük' },    // %5 faiz
            14: { rate: 0.10, name: '14 Günlük' },  // %10 faiz
            30: { rate: 0.20, name: '30 Günlük' }   // %20 faiz
        },
        earlyBreakPenalty: 0.05,          // Erken bozma cezası %5
        minAmount: 1000                   // Minimum yatırım
    },
    
    // Kredi Sistemi
    credit: {
        baseLimit: 10000,                 // Temel kredi limiti
        interestRate: 0.15,               // Faiz oranı %15
        minCreditScore: 500,              // Minimum kredi notu
        paymentPeriod: 7,                 // Ödeme süresi (gün)
        xpGain: 20                        // Ödeme başına XP
    },
    
    // Kredi Notu
    creditScore: {
        initial: 1000,                    // Başlangıç notu
        max: 2000,                        // Maksimum not
        min: 0,                           // Minimum not
        paymentBonus: 50,                 // Ödeme bonusu
        latePenalty: 100,                 // Gecikme cezası
        billPaymentBonus: 10              // Fatura ödeme bonusu
    },
    
    // Temerrüt Sistemi
    default: {
        gracePeriod: 24 * 60 * 60 * 1000,     // 24 saat (ms)
        lateFee: 0.10,                         // Gecikme cezası %10
        dailyInterest: 0.01,                   // Günlük faiz %1
        severeDefaultDays: 7,                  // Ağır temerrüt (gün)
        freezeAccountDays: 14,                 // Hesap dondurma (gün)
        salaryDeduction: 0.30                  // Maaş kesintisi %30
    },
    
    // Borç Yapılandırma
    restructure: {
        minDebt: 5000,                    // Minimum borç
        interestReduction: 0.50,          // Faiz indirimi %50
        installments: [3, 6, 12],         // Taksit seçenekleri
        creditScoreRecovery: 5            // Taksit başına not düzelmesi
    },
    
    // Faturalar
    bills: {
        types: {
            'elektrik': { amount: 500, name: 'Elektrik Faturası' },
            'internet': { amount: 300, name: 'İnternet Faturası' },
            'su': { amount: 200, name: 'Su Faturası' },
            'telefon': { amount: 250, name: 'Telefon Faturası' }
        },
        unpaidPenalty: 25,                // Ödenmemiş fatura not düşüşü
        generationDay: 1                   // Her ayın 1'i
    },
    
    // Vergiler
    taxes: {
        income: 0.10,                     // Gelir vergisi %10
        transfer: 0.02,                   // Transfer vergisi %2
        withdrawal: 0.01                  // Çekim vergisi %1
    },
    
    // Level Sistemi
    levels: {
        xpPerLevel: 1000,                 // Level başına XP
        maxLevel: 100,                    // Maksimum level
        limitMultiplier: 1.1,             // Level başına limit artışı
        interestReduction: 0.005          // Level başına faiz düşüşü
    },
    
    // Anti-Spam & Güvenlik
    security: {
        commandCooldown: 3000,            // Komut cooldown (ms)
        maxCommandsPerMinute: 20,         // Dakika başına max komut
        minAccountAge: 7,                 // Minimum hesap yaşı (gün)
        dailyEarningLimit: 100000         // Günlük kazanç limiti
    },
    
    // Liderlik Tablosu
    leaderboard: {
        pageSize: 10                      // Sayfa başına kullanıcı
    },
    
    // Log Ayarları
    logging: {
        enabled: true,
        maxLogs: 100                      // Kullanıcı başına max log
    }
};
