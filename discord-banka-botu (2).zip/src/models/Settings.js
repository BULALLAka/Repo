/**
 * ========================================
 * AYARLAR MODELİ (MongoDB Schema)
 * ========================================
 * Admin tarafından değiştirilebilir global ayarlar
 */

const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
    // Tek bir ayar dökümanı olacak
    _id: { type: String, default: 'global_settings' },
    
    // Vergi Oranları
    taxes: {
        income: { type: Number, default: 0.10 },
        transfer: { type: Number, default: 0.02 },
        withdrawal: { type: Number, default: 0.01 }
    },
    
    // Faiz Oranları
    interest: {
        credit: { type: Number, default: 0.15 },
        savings7: { type: Number, default: 0.05 },
        savings14: { type: Number, default: 0.10 },
        savings30: { type: Number, default: 0.20 },
        defaultDaily: { type: Number, default: 0.01 }
    },
    
    // Limitler
    limits: {
        dailyTransfer: { type: Number, default: 500000 },
        hourlyTransfer: { type: Number, default: 100000 },
        dailyEarning: { type: Number, default: 100000 },
        maxCredit: { type: Number, default: 1000000 }
    },
    
    // Cezalar
    penalties: {
        lateFee: { type: Number, default: 0.10 },
        earlyBreak: { type: Number, default: 0.05 },
        defaultSalary: { type: Number, default: 0.30 }
    },
    
    // Ekonomi Durumu
    economy: {
        inflationRate: { type: Number, default: 0 },
        totalMoney: { type: Number, default: 0 },
        totalDebt: { type: Number, default: 0 },
        totalUsers: { type: Number, default: 0 },
        lastUpdated: { type: Date, default: Date.now }
    },
    
    // Bakım Modu
    maintenance: {
        enabled: { type: Boolean, default: false },
        message: { type: String, default: 'Bot bakımda, lütfen daha sonra tekrar deneyin.' }
    },
    
    updatedAt: { type: Date, default: Date.now },
    updatedBy: { type: String, default: null }
});

// Kaydetmeden önce
settingsSchema.pre('save', function(next) {
    this.updatedAt = new Date();
    next();
});

// Singleton pattern - Her zaman tek bir ayar dökümanı döndür
settingsSchema.statics.getSettings = async function() {
    let settings = await this.findById('global_settings');
    if (!settings) {
        settings = await this.create({ _id: 'global_settings' });
    }
    return settings;
};

module.exports = mongoose.model('Settings', settingsSchema);
