/**
 * ========================================
 * KULLANICI MODELİ (MongoDB Schema)
 * ========================================
 * Global banka hesap yapısı
 */

const mongoose = require('mongoose');

// İşlem Geçmişi Alt Şeması
const transactionSchema = new mongoose.Schema({
    type: {
        type: String,
        enum: ['deposit', 'withdraw', 'transfer_in', 'transfer_out', 'salary', 'work', 
               'credit', 'credit_payment', 'bill', 'tax', 'penalty', 'interest', 
               'savings_deposit', 'savings_withdraw', 'admin'],
        required: true
    },
    amount: { type: Number, required: true },
    description: { type: String, required: true },
    balanceAfter: { type: Number, required: true },
    relatedUser: { type: String, default: null },
    timestamp: { type: Date, default: Date.now }
});

// Vadeli Hesap Alt Şeması
const savingsAccountSchema = new mongoose.Schema({
    amount: { type: Number, required: true },
    period: { type: Number, required: true }, // 7, 14, 30 gün
    interestRate: { type: Number, required: true },
    startDate: { type: Date, default: Date.now },
    endDate: { type: Date, required: true },
    status: { type: String, enum: ['active', 'completed', 'broken'], default: 'active' }
});

// Fatura Alt Şeması
const billSchema = new mongoose.Schema({
    type: { type: String, required: true },
    amount: { type: Number, required: true },
    dueDate: { type: Date, required: true },
    paid: { type: Boolean, default: false },
    paidDate: { type: Date, default: null }
});

// Yapılandırma Alt Şeması
const restructureSchema = new mongoose.Schema({
    originalDebt: { type: Number, required: true },
    totalAmount: { type: Number, required: true },
    installmentAmount: { type: Number, required: true },
    installments: { type: Number, required: true },
    paidInstallments: { type: Number, default: 0 },
    nextPaymentDate: { type: Date, required: true },
    startDate: { type: Date, default: Date.now },
    status: { type: String, enum: ['active', 'completed', 'defaulted'], default: 'active' }
});

// Ana Kullanıcı Şeması
const userSchema = new mongoose.Schema({
    // Temel Bilgiler
    odgUserI: { 
        type: String, 
        required: true, 
        unique: true,
        index: true 
    },
    username: { type: String, required: true },
    iban: { 
        type: String, 
        unique: true,
        required: true 
    },
    
    // Hesap Durumu
    accountStatus: { 
        type: String, 
        enum: ['active', 'frozen', 'suspended', 'closed'],
        default: 'active'
    },
    
    // Bakiyeler
    balance: { type: Number, default: 0, min: 0 },
    
    // Vadeli Hesap
    savingsAccounts: [savingsAccountSchema],
    
    // Meslek Sistemi
    job: { type: String, default: 'işsiz' },
    
    // Level & XP
    level: { type: Number, default: 1, min: 1 },
    xp: { type: Number, default: 0, min: 0 },
    
    // Kredi Sistemi
    creditDebt: { type: Number, default: 0, min: 0 },
    creditDueDate: { type: Date, default: null },
    creditHistory: [{
        amount: Number,
        date: { type: Date, default: Date.now },
        paid: { type: Boolean, default: false },
        paidDate: Date
    }],
    
    // Kredi Notu
    creditScore: { type: Number, default: 1000 },
    
    // Temerrüt Durumu
    defaulted: { type: Boolean, default: false },
    defaultStartDate: { type: Date, default: null },
    defaultDays: { type: Number, default: 0 },
    defaultPenaltyApplied: { type: Boolean, default: false },
    
    // Borç Yapılandırma
    restructure: { type: restructureSchema, default: null },
    
    // Yapılandırılmış Borç (scheduler için)
    restructuredDebt: {
        active: { type: Boolean, default: false },
        totalAmount: { type: Number, default: 0 },
        remainingAmount: { type: Number, default: 0 },
        monthlyPayment: { type: Number, default: 0 },
        totalInstallments: { type: Number, default: 0 },
        paidInstallments: { type: Number, default: 0 },
        missedPayments: { type: Number, default: 0 },
        nextPaymentDate: { type: Date, default: null },
        startDate: { type: Date, default: null }
    },
    
    // Vadeli hesap (eski format uyumluluğu)
    savings: { type: Number, default: 0 },
    savingsStartDate: { type: Date, default: null },
    savingsMaturityDate: { type: Date, default: null },
    savingsTerm: { type: Number, default: 0 },
    savingsInterestRate: { type: Number, default: 0 },
    
    // Ağır temerrüt
    severeDefault: { type: Boolean, default: false },
    
    // Hesap dondurma
    accountFrozen: { type: Boolean, default: false },
    frozenAt: { type: Date, default: null },
    frozenReason: { type: String, default: null },
    
    // Son fatura tarihi
    lastBillDate: { type: Date, default: null },
    
    // Kredi faiz oranı
    creditInterestRate: { type: Number, default: 0 },
    totalCreditTaken: { type: Number, default: 0 },
    
    // Faturalar
    bills: [billSchema],
    
    // Transfer Limitleri (Günlük/Saatlik takip)
    dailyTransfers: { type: Number, default: 0 },
    hourlyTransfers: { type: Number, default: 0 },
    lastTransferReset: { type: Date, default: Date.now },
    lastHourlyReset: { type: Date, default: Date.now },
    
    // Günlük Kazanç Takibi
    dailyEarnings: { type: Number, default: 0 },
    lastEarningsReset: { type: Date, default: Date.now },
    
    // Cooldown'lar
    lastWork: { type: Date, default: null },
    lastSalary: { type: Date, default: null },
    lastDaily: { type: Date, default: null },
    
    // İşlem Geçmişi
    transactions: [transactionSchema],
    
    // İstatistikler
    stats: {
        totalEarned: { type: Number, default: 0 },
        totalSpent: { type: Number, default: 0 },
        totalTransferred: { type: Number, default: 0 },
        totalReceived: { type: Number, default: 0 },
        creditsRepaid: { type: Number, default: 0 },
        billsPaid: { type: Number, default: 0 },
        workCount: { type: Number, default: 0 }
    },
    
    // Tarihler
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now },
    lastActive: { type: Date, default: Date.now }
});

// IBAN Oluşturma Fonksiyonu
userSchema.statics.generateIBAN = function() {
    const countryCode = 'TR';
    const checkDigits = Math.floor(10 + Math.random() * 90).toString();
    const bankCode = '0001'; // Sanal banka kodu
    const accountNumber = Array.from({ length: 16 }, () => Math.floor(Math.random() * 10)).join('');
    return `${countryCode}${checkDigits}${bankCode}${accountNumber}`;
};

// Toplam Vadeli Bakiye Hesaplama
userSchema.methods.getTotalSavings = function() {
    return this.savingsAccounts
        .filter(acc => acc.status === 'active')
        .reduce((total, acc) => total + acc.amount, 0);
};

// Toplam Varlık Hesaplama
userSchema.methods.getTotalAssets = function() {
    return this.balance + this.getTotalSavings();
};

// Net Değer Hesaplama (Varlıklar - Borçlar)
userSchema.methods.getNetWorth = function() {
    return this.getTotalAssets() - this.creditDebt;
};

// XP Ekleme ve Level Kontrolü
userSchema.methods.addXP = async function(amount, config) {
    this.xp += amount;
    const xpNeeded = this.level * config.levels.xpPerLevel;
    
    if (this.xp >= xpNeeded && this.level < config.levels.maxLevel) {
        this.level += 1;
        this.xp -= xpNeeded;
        await this.save();
        return { leveledUp: true, newLevel: this.level };
    }
    
    await this.save();
    return { leveledUp: false };
};

// İşlem Ekleme
userSchema.methods.addTransaction = function(type, amount, description, relatedUser = null) {
    // Maksimum log sayısını kontrol et
    if (this.transactions.length >= 100) {
        this.transactions.shift(); // En eski kaydı sil
    }
    
    this.transactions.push({
        type,
        amount,
        description,
        balanceAfter: this.balance,
        relatedUser,
        timestamp: new Date()
    });
};

// Kredi Limiti Hesaplama
userSchema.methods.getCreditLimit = function(config) {
    const baseLimit = config.credit.baseLimit;
    const levelBonus = this.level * 2000;
    const jobMultiplier = {
        'işsiz': 0.5,
        'memur': 1.0,
        'esnaf': 1.2,
        'freelancer': 1.3,
        'yazılımcı': 1.5,
        'bankacı': 2.0,
        'yönetici': 2.5
    }[this.job] || 1.0;
    const scoreMultiplier = this.creditScore / 1000;
    
    return Math.floor((baseLimit + levelBonus) * jobMultiplier * scoreMultiplier);
};

// Faiz Oranı Hesaplama (Level'e göre düşer)
userSchema.methods.getInterestRate = function(config) {
    const baseRate = config.credit.interestRate;
    const levelReduction = (this.level - 1) * config.levels.interestReduction;
    return Math.max(0.05, baseRate - levelReduction); // Minimum %5
};

// Transfer Limiti Hesaplama
userSchema.methods.getTransferLimit = function(config) {
    const baseLimit = config.transfer.dailyLimit;
    const levelMultiplier = Math.pow(config.levels.limitMultiplier, this.level - 1);
    return Math.floor(baseLimit * levelMultiplier);
};

// Temerrüt Günü Hesaplama
userSchema.methods.calculateDefaultDays = function() {
    if (!this.defaultStartDate) return 0;
    const now = new Date();
    const diffTime = Math.abs(now - this.defaultStartDate);
    return Math.floor(diffTime / (1000 * 60 * 60 * 24));
};

// Günlük/Saatlik Reset Kontrolü
userSchema.methods.checkAndResetLimits = function() {
    const now = new Date();
    
    // Günlük reset
    if (now - this.lastTransferReset >= 24 * 60 * 60 * 1000) {
        this.dailyTransfers = 0;
        this.lastTransferReset = now;
    }
    
    // Saatlik reset
    if (now - this.lastHourlyReset >= 60 * 60 * 1000) {
        this.hourlyTransfers = 0;
        this.lastHourlyReset = now;
    }
    
    // Günlük kazanç reset
    if (now - this.lastEarningsReset >= 24 * 60 * 60 * 1000) {
        this.dailyEarnings = 0;
        this.lastEarningsReset = now;
    }
};

// Level Kontrolü (scheduler için)
userSchema.methods.checkLevelUp = async function () {
	const xpNeeded = this.level * 1000;
	while (this.xp >= xpNeeded && this.level < 100) {
		this.xp -= xpNeeded;
		this.level += 1;
	}
};

// Kaydetmeden önce güncelleme tarihi
userSchema.pre("save", function (next) {
	this.updatedAt = new Date();
	this.lastActive = new Date();
	next();
});

// İndeksler
userSchema.index({ balance: -1 });
userSchema.index({ creditScore: -1 });
userSchema.index({ level: -1 });
userSchema.index({ creditDebt: -1 });

module.exports = mongoose.model('User', userSchema);
