/**
 * ========================================
 * YARDIMCI FONKSİYONLAR
 * ========================================
 */

const { EmbedBuilder } = require('discord.js');
const config = require('../config/config');

/**
 * Para formatla
 */
function formatMoney(amount) {
    return `${Number(amount).toLocaleString('tr-TR')} TL`;
}

/**
 * Yüzde formatla
 */
function formatPercent(rate) {
    return `%${(rate * 100).toFixed(1)}`;
}

/**
 * Tarih formatla
 */
function formatDate(date) {
    if (!date) return 'Belirtilmemiş';
    return new Date(date).toLocaleDateString('tr-TR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/**
 * Kısa tarih formatla
 */
function formatShortDate(date) {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('tr-TR');
}

/**
 * Süre formatla (milisaniye -> okunabilir)
 */
function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days} gün ${hours % 24} saat`;
    if (hours > 0) return `${hours} saat ${minutes % 60} dakika`;
    if (minutes > 0) return `${minutes} dakika ${seconds % 60} saniye`;
    return `${seconds} saniye`;
}

/**
 * Kalan süre hesapla
 */
function getRemainingTime(lastTime, cooldown) {
    if (!lastTime) return 0;
    const elapsed = Date.now() - new Date(lastTime).getTime();
    return Math.max(0, cooldown - elapsed);
}

/**
 * Cooldown kontrol
 */
function isOnCooldown(lastTime, cooldown) {
    return getRemainingTime(lastTime, cooldown) > 0;
}

/**
 * IBAN formatla (boşluklarla)
 */
function formatIBAN(iban) {
    if (!iban) return 'Yok';
    return iban.match(/.{1,4}/g).join(' ');
}

/**
 * IBAN doğrula
 */
function validateIBAN(iban) {
    const cleanIBAN = iban.replace(/\s/g, '').toUpperCase();
    return /^TR\d{24}$/.test(cleanIBAN);
}

/**
 * Seviye için gerekli XP
 */
function getXPForLevel(level, configData = config) {
    return level * configData.levels.xpPerLevel;
}

/**
 * XP progress bar oluştur
 */
function createProgressBar(current, max, length = 10) {
    const progress = Math.min(Math.floor((current / max) * length), length);
    const filled = '█'.repeat(progress);
    const empty = '░'.repeat(length - progress);
    return `[${filled}${empty}]`;
}

/**
 * Kredi notu değerlendirmesi
 */
function getCreditScoreRating(score) {
    if (score >= 1800) return { rating: 'Mükemmel', emoji: '🌟', color: 0x00FF00 };
    if (score >= 1500) return { rating: 'Çok İyi', emoji: '⭐', color: 0x90EE90 };
    if (score >= 1200) return { rating: 'İyi', emoji: '✅', color: 0xFFFF00 };
    if (score >= 900) return { rating: 'Orta', emoji: '⚠️', color: 0xFFA500 };
    if (score >= 600) return { rating: 'Düşük', emoji: '🔶', color: 0xFF8C00 };
    if (score >= 300) return { rating: 'Kötü', emoji: '🔴', color: 0xFF4500 };
    return { rating: 'Çok Kötü', emoji: '💀', color: 0xFF0000 };
}

/**
 * Hesap durumu emoji
 */
function getAccountStatusEmoji(status) {
    const statuses = {
        'active': '🟢',
        'frozen': '🔵',
        'suspended': '🟠',
        'closed': '🔴'
    };
    return statuses[status] || '⚪';
}

/**
 * Hesap durumu açıklama
 */
function getAccountStatusText(status) {
    const statuses = {
        'active': 'Aktif',
        'frozen': 'Dondurulmuş',
        'suspended': 'Askıda',
        'closed': 'Kapalı'
    };
    return statuses[status] || 'Bilinmiyor';
}

/**
 * Meslek emoji
 */
function getJobEmoji(job) {
    const emojis = {
        'işsiz': '😔',
        'memur': '👔',
        'esnaf': '🏪',
        'freelancer': '💻',
        'yazılımcı': '👨‍💻',
        'bankacı': '🏦',
        'yönetici': '👑'
    };
    return emojis[job] || '👤';
}

/**
 * Başarı embed'i oluştur
 */
function createSuccessEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(config.colors.success)
        .setTitle(`✅ ${title}`)
        .setDescription(description)
        .setTimestamp();
}

/**
 * Hata embed'i oluştur
 */
function createErrorEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(config.colors.error)
        .setTitle(`❌ ${title}`)
        .setDescription(description)
        .setTimestamp();
}

/**
 * Bilgi embed'i oluştur
 */
function createInfoEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(config.colors.info)
        .setTitle(`ℹ️ ${title}`)
        .setDescription(description)
        .setTimestamp();
}

/**
 * Uyarı embed'i oluştur
 */
function createWarningEmbed(title, description) {
    return new EmbedBuilder()
        .setColor(config.colors.warning)
        .setTitle(`⚠️ ${title}`)
        .setDescription(description)
        .setTimestamp();
}

/**
 * Banka embed'i oluştur
 */
function createBankEmbed(title) {
    return new EmbedBuilder()
        .setColor(config.colors.bank)
        .setTitle(`🏦 ${title}`)
        .setTimestamp()
        .setFooter({ text: 'Global Banka Sistemi' });
}

/**
 * Rastgele sayı üret (min-max arası)
 */
function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Miktar parse et (1k, 1m, all destekli)
 */
function parseAmount(input, maxAmount = null) {
    if (!input) return null;
    
    const str = input.toString().toLowerCase().trim();
    
    // "all" veya "hepsi" kontrolü
    if (str === 'all' || str === 'hepsi' || str === 'tümü') {
        return maxAmount || 0;
    }
    
    // Kısaltma kontrolü (k, m, b)
    let multiplier = 1;
    let numStr = str;
    
    if (str.endsWith('k')) {
        multiplier = 1000;
        numStr = str.slice(0, -1);
    } else if (str.endsWith('m')) {
        multiplier = 1000000;
        numStr = str.slice(0, -1);
    } else if (str.endsWith('b')) {
        multiplier = 1000000000;
        numStr = str.slice(0, -1);
    }
    
    const num = parseFloat(numStr);
    if (isNaN(num) || num < 0) return null;
    
    return Math.floor(num * multiplier);
}

/**
 * Kullanıcı mention'dan ID çıkar
 */
function extractUserId(mention) {
    if (!mention) return null;
    
    // Zaten bir ID ise
    if (/^\d{17,19}$/.test(mention)) {
        return mention;
    }
    
    // Mention formatı <@!123456789> veya <@123456789>
    const match = mention.match(/^<@!?(\d{17,19})>$/);
    return match ? match[1] : null;
}

/**
 * Hesap yaşı kontrolü (anti-alt)
 */
function checkAccountAge(createdAt, minDays) {
    const accountAge = (Date.now() - new Date(createdAt).getTime()) / (1000 * 60 * 60 * 24);
    return accountAge >= minDays;
}

/**
 * Güvenli bölme (0'a bölme hatası önleme)
 */
function safeDivide(a, b, defaultValue = 0) {
    return b !== 0 ? a / b : defaultValue;
}

/**
 * Sayıyı yuvarlak göster
 */
function abbreviateNumber(num) {
    if (num >= 1e9) return (num / 1e9).toFixed(1) + 'B';
    if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
    if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
    return num.toString();
}

module.exports = {
    formatMoney,
    formatPercent,
    formatDate,
    formatShortDate,
    formatDuration,
    getRemainingTime,
    isOnCooldown,
    formatIBAN,
    validateIBAN,
    getXPForLevel,
    createProgressBar,
    getCreditScoreRating,
    getAccountStatusEmoji,
    getAccountStatusText,
    getJobEmoji,
    createSuccessEmbed,
    createErrorEmbed,
    createInfoEmbed,
    createWarningEmbed,
    createBankEmbed,
    randomInt,
    parseAmount,
    extractUserId,
    checkAccountAge,
    safeDivide,
    abbreviateNumber
};
