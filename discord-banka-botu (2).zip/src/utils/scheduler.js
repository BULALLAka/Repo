/**
 * Zamanlanmis Gorevler
 * - Temerrut kontrolu
 * - Fatura olusturma
 * - Vadeli hesap kontrolu
 * - Hesap dondurma
 */

const User = require("../models/User");
const Settings = require("../models/Settings");
const config = require("../config/config");

/**
 * Temerrut kontrolu - Her saat calisir
 */
async function checkDefaults() {
	console.log("[Scheduler] Temerrut kontrolu basliyor...");

	try {
		const settings = await Settings.getSettings();

		// Kredi borcu olan ve vadesi gecmis kullanicilar
		const usersWithDebt = await User.find({
			creditDebt: { $gt: 0 },
			creditDueDate: { $lt: new Date() },
		});

		for (const user of usersWithDebt) {
			const now = new Date();
			const dueDate = new Date(user.creditDueDate);
			const daysPassed = Math.floor(
				(now.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24),
			);

			// Temerrute dusur
			if (!user.defaulted && daysPassed >= 1) {
				user.defaulted = true;
				user.defaultStartDate = dueDate;
				user.defaultDays = daysPassed;

				// %10 gecikme cezasi
				const penalty = Math.floor(user.creditDebt * 0.1);
				user.creditDebt += penalty;

				// Kredi notu dusur
				user.creditScore = Math.max(0, user.creditScore - 50);

				console.log(
					`[Scheduler] ${user.odgUserI} temerrute dustu. Ceza: ${penalty}`,
				);
			}

			// Temerrut gunlerini guncelle
			if (user.defaulted) {
				user.defaultDays = daysPassed;

				// Gunluk faiz ekle (%1)
				const dailyInterest = Math.floor(
					user.creditDebt * (settings.defaultDailyInterest / 100),
				);
				user.creditDebt += dailyInterest;

				// 7 gun -> agir temerrut
				if (daysPassed >= 7 && !user.severeDefault) {
					user.severeDefault = true;
					user.creditScore = Math.max(0, user.creditScore - 100);
					console.log(`[Scheduler] ${user.odgUserI} agir temerrute dustu.`);
				}

				// 14 gun -> hesap dondurma
				if (daysPassed >= 14 && !user.accountFrozen) {
					user.accountFrozen = true;
					user.frozenAt = new Date();
					user.frozenReason = "Temerrut nedeniyle otomatik dondurma";
					console.log(`[Scheduler] ${user.odgUserI} hesabi donduruldu.`);
				}
			}

			await user.save();
		}

		console.log(
			`[Scheduler] Temerrut kontrolu tamamlandi. ${usersWithDebt.length} kullanici kontrol edildi.`,
		);
	} catch (error) {
		console.error("[Scheduler] Temerrut kontrolu hatasi:", error);
	}
}

/**
 * Fatura olusturma - Her gun calisir
 */
async function generateBills() {
	console.log("[Scheduler] Fatura olusturma basliyor...");

	try {
		const users = await User.find({ accountFrozen: false });
		const now = new Date();

		for (const user of users) {
			// Son fatura tarihini kontrol et
			const lastBillDate = user.lastBillDate || user.createdAt;
			const daysSinceLastBill = Math.floor(
				(now.getTime() - new Date(lastBillDate).getTime()) /
					(1000 * 60 * 60 * 24),
			);

			// 30 gunde bir fatura olustur
			if (daysSinceLastBill >= 30) {
				// Eski odemenmis faturalari kontrol et
				const unpaidBills = user.bills.filter((b) => !b.paid);
				if (unpaidBills.length > 0) {
					// Odemenmis fatura varsa kredi notu dusur
					user.creditScore = Math.max(
						0,
						user.creditScore - unpaidBills.length * 10,
					);
				}

				// Yeni faturalar olustur
				const billTypes = ["elektrik", "internet", "su", "telefon"];
				for (const type of billTypes) {
					const billConfig = config.bills[type];
					const amount =
						Math.floor(
							Math.random() * (billConfig.max - billConfig.min + 1),
						) + billConfig.min;

					user.bills.push({
						type: type,
						amount: amount,
						dueDate: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000),
						paid: false,
						createdAt: now,
					});
				}

				user.lastBillDate = now;
				await user.save();

				console.log(`[Scheduler] ${user.odgUserI} icin faturalar olusturuldu.`);
			}
		}

		console.log(
			`[Scheduler] Fatura olusturma tamamlandi. ${users.length} kullanici kontrol edildi.`,
		);
	} catch (error) {
		console.error("[Scheduler] Fatura olusturma hatasi:", error);
	}
}

/**
 * Vadeli hesap kontrolu - Her saat calisir
 */
async function checkSavingsAccounts() {
	console.log("[Scheduler] Vadeli hesap kontrolu basliyor...");

	try {
		const settings = await Settings.getSettings();
		const now = new Date();

		// Vadesi dolmus vadeli hesaplar
		const usersWithMatureSavings = await User.find({
			savings: { $gt: 0 },
			savingsMaturityDate: { $lte: now },
		});

		for (const user of usersWithMatureSavings) {
			// Faiz hesapla
			let interestRate;
			switch (user.savingsTerm) {
				case 7:
					interestRate = settings.savingsInterest7;
					break;
				case 14:
					interestRate = settings.savingsInterest14;
					break;
				case 30:
					interestRate = settings.savingsInterest30;
					break;
				default:
					interestRate = 3;
			}

			const interest = Math.floor(user.savings * (interestRate / 100));
			const total = user.savings + interest;

			// Ana hesaba aktar
			user.balance += total;

			// Transaction kaydi
			await user.addTransaction({
				type: "savings_matured",
				amount: total,
				description: `Vadeli hesap vadesi doldu. Faiz: ${interest}`,
				balanceAfter: user.balance,
			});

			// Vadeli hesabi sifirla
			user.savings = 0;
			user.savingsStartDate = null;
			user.savingsMaturityDate = null;
			user.savingsTerm = 0;
			user.savingsInterestRate = 0;

			// XP ekle
			user.xp += Math.floor(total / 100);
			await user.checkLevelUp();

			await user.save();

			console.log(
				`[Scheduler] ${user.odgUserI} vadeli hesabi vadeye ulasti. Toplam: ${total}`,
			);
		}

		console.log(
			`[Scheduler] Vadeli hesap kontrolu tamamlandi. ${usersWithMatureSavings.length} hesap islendi.`,
		);
	} catch (error) {
		console.error("[Scheduler] Vadeli hesap kontrolu hatasi:", error);
	}
}

/**
 * Gunluk limitleri sifirla - Her gun gece yarisi
 */
async function resetDailyLimits() {
	console.log("[Scheduler] Gunluk limitler sifirlaniyor...");

	try {
		await User.updateMany(
			{},
			{
				$set: {
					dailyTransferAmount: 0,
					dailyEarnings: 0,
					hourlyTransferAmount: 0,
					lastHourlyReset: new Date(),
				},
			},
		);

		console.log("[Scheduler] Gunluk limitler sifirlandi.");
	} catch (error) {
		console.error("[Scheduler] Gunluk limit sifirlama hatasi:", error);
	}
}

/**
 * Saatlik limitleri sifirla
 */
async function resetHourlyLimits() {
	console.log("[Scheduler] Saatlik limitler sifirlaniyor...");

	try {
		await User.updateMany(
			{},
			{
				$set: {
					hourlyTransferAmount: 0,
					lastHourlyReset: new Date(),
				},
			},
		);

		console.log("[Scheduler] Saatlik limitler sifirlandi.");
	} catch (error) {
		console.error("[Scheduler] Saatlik limit sifirlama hatasi:", error);
	}
}

/**
 * Yapilandirma taksit kontrolu - Her gun calisir
 */
async function checkRestructuredPayments() {
	console.log("[Scheduler] Yapilandirma kontrolu basliyor...");

	try {
		const now = new Date();

		// Yapilandirilmis borcu olan kullanicilar
		const usersWithRestructured = await User.find({
			"restructuredDebt.active": true,
		});

		for (const user of usersWithRestructured) {
			const restructured = user.restructuredDebt;
			const nextPaymentDate = new Date(restructured.nextPaymentDate);

			// Taksit tarihi geldiyse
			if (now >= nextPaymentDate) {
				const installment = restructured.monthlyPayment;

				// Bakiye yeterliyse otomatik ode
				if (user.balance >= installment) {
					user.balance -= installment;
					restructured.remainingAmount -= installment;
					restructured.paidInstallments += 1;

					// Transaction kaydi
					await user.addTransaction({
						type: "restructured_payment",
						amount: -installment,
						description: `Yapilandirma taksiti odendi (${restructured.paidInstallments}/${restructured.totalInstallments})`,
						balanceAfter: user.balance,
					});

					// Tum taksitler odendiyse
					if (restructured.paidInstallments >= restructured.totalInstallments) {
						restructured.active = false;
						user.creditDebt = 0;
						user.creditScore = Math.min(2000, user.creditScore + 50);

						console.log(
							`[Scheduler] ${user.odgUserI} yapilandirma tamamlandi.`,
						);
					} else {
						// Sonraki taksit tarihi
						restructured.nextPaymentDate = new Date(
							nextPaymentDate.getTime() + 30 * 24 * 60 * 60 * 1000,
						);
					}

					// Kredi notu artir
					user.creditScore = Math.min(2000, user.creditScore + 5);
				} else {
					// Bakiye yetersiz - temerrut
					user.defaulted = true;
					user.creditScore = Math.max(0, user.creditScore - 30);
					restructured.missedPayments += 1;

					// 3 kez kacirilirsa yapilandirma iptal
					if (restructured.missedPayments >= 3) {
						restructured.active = false;
						user.creditDebt = restructured.remainingAmount;
						user.creditDueDate = new Date();

						console.log(
							`[Scheduler] ${user.odgUserI} yapilandirma iptal edildi.`,
						);
					}
				}

				await user.save();
			}
		}

		console.log(
			`[Scheduler] Yapilandirma kontrolu tamamlandi. ${usersWithRestructured.length} kullanici kontrol edildi.`,
		);
	} catch (error) {
		console.error("[Scheduler] Yapilandirma kontrolu hatasi:", error);
	}
}

/**
 * Tum zamanlayicilari baslat
 */
function startScheduler() {
	console.log("[Scheduler] Zamanlanmis gorevler baslatiliyor...");

	// Her saat
	setInterval(
		() => {
			checkDefaults();
			checkSavingsAccounts();
			resetHourlyLimits();
		},
		60 * 60 * 1000,
	);

	// Her 6 saatte
	setInterval(
		() => {
			generateBills();
			checkRestructuredPayments();
		},
		6 * 60 * 60 * 1000,
	);

	// Her gun gece yarisi (24 saat)
	setInterval(
		() => {
			resetDailyLimits();
		},
		24 * 60 * 60 * 1000,
	);

	// Baslangicta bir kez calistir
	setTimeout(() => {
		checkDefaults();
		checkSavingsAccounts();
		generateBills();
		checkRestructuredPayments();
	}, 5000);

	console.log("[Scheduler] Zamanlanmis gorevler baslatildi.");
}

module.exports = {
	startScheduler,
	checkDefaults,
	generateBills,
	checkSavingsAccounts,
	resetDailyLimits,
	resetHourlyLimits,
	checkRestructuredPayments,
};
