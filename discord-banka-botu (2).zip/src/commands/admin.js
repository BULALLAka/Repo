/**
 * Admin Komutlari - Sadece ikashop1 kullanabilir
 */

const { EmbedBuilder } = require("discord.js");
const User = require("../models/User");
const Settings = require("../models/Settings");
const config = require("../config/config");
const { formatMoney, isAdmin } = require("../utils/helpers");

module.exports = {
	// Admin Panel
	"admin-panel": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const settings = await Settings.getSettings();
		const totalUsers = await User.countDocuments();
		const totalBalance = await User.aggregate([
			{ $group: { _id: null, total: { $sum: "$balance" } } },
		]);
		const totalDebt = await User.aggregate([
			{ $group: { _id: null, total: { $sum: "$creditDebt" } } },
		]);
		const defaultedUsers = await User.countDocuments({ defaulted: true });
		const frozenUsers = await User.countDocuments({ accountFrozen: true });

		const embed = new EmbedBuilder()
			.setColor(config.colors.admin)
			.setTitle("Admin Paneli")
			.setDescription("Banka yonetim sistemi")
			.addFields(
				{
					name: "Genel Istatistikler",
					value: [
						`Toplam Kullanici: **${totalUsers}**`,
						`Toplam Bakiye: **${formatMoney(totalBalance[0]?.total || 0)}**`,
						`Toplam Borc: **${formatMoney(totalDebt[0]?.total || 0)}**`,
						`Temerrutlu: **${defaultedUsers}**`,
						`Dondurulmus: **${frozenUsers}**`,
					].join("\n"),
					inline: false,
				},
				{
					name: "Ekonomi Ayarlari",
					value: [
						`Transfer Vergisi: **%${settings.transferTax}**`,
						`Gelir Vergisi: **%${settings.incomeTax}**`,
						`Kredi Faizi: **%${settings.creditInterest}**`,
						`Vadeli Faiz (7g): **%${settings.savingsInterest7}**`,
						`Vadeli Faiz (14g): **%${settings.savingsInterest14}**`,
						`Vadeli Faiz (30g): **%${settings.savingsInterest30}**`,
					].join("\n"),
					inline: true,
				},
				{
					name: "Limitler",
					value: [
						`Gunluk Transfer: **${formatMoney(settings.dailyTransferLimit)}**`,
						`Saatlik Transfer: **${formatMoney(settings.hourlyTransferLimit)}**`,
						`Gunluk Kazanc: **${formatMoney(settings.dailyEarningLimit)}**`,
					].join("\n"),
					inline: true,
				},
				{
					name: "Admin Komutlari",
					value: [
						"`!faiz-ayarla <tur> <oran>` - Faiz ayarla",
						"`!vergi-ayarla <tur> <oran>` - Vergi ayarla",
						"`!hesap-dondur @kisi` - Hesap dondur",
						"`!hesap-ac @kisi` - Hesap ac",
						"`!borc-sil @kisi` - Borc sil",
						"`!para-ekle @kisi <miktar>` - Para ekle",
						"`!para-sil @kisi <miktar>` - Para sil",
						"`!temerrut-kaldir @kisi` - Temerrut kaldir",
						"`!ekonomi-sifirla` - Ekonomiyi sifirla",
						"`!ekonomi-rapor` - Detayli rapor",
					].join("\n"),
					inline: false,
				},
			)
			.setFooter({ text: `Admin: ${message.author.username}` })
			.setTimestamp();

		return message.reply({ embeds: [embed] });
	},

	// Faiz Ayarla
	"faiz-ayarla": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const type = args[0]?.toLowerCase();
		const rate = Number.parseFloat(args[1]);

		if (!type || Number.isNaN(rate) || rate < 0 || rate > 100) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription(
							"Kullanim: `!faiz-ayarla <kredi|vadeli7|vadeli14|vadeli30> <oran>`",
						),
				],
			});
		}

		const settings = await Settings.getSettings();

		switch (type) {
			case "kredi":
				settings.creditInterest = rate;
				break;
			case "vadeli7":
				settings.savingsInterest7 = rate;
				break;
			case "vadeli14":
				settings.savingsInterest14 = rate;
				break;
			case "vadeli30":
				settings.savingsInterest30 = rate;
				break;
			default:
				return message.reply({
					embeds: [
						new EmbedBuilder()
							.setColor(config.colors.error)
							.setDescription(
								"Gecersiz faiz turu. Kullanilabilir: kredi, vadeli7, vadeli14, vadeli30",
							),
					],
				});
		}

		await settings.save();

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Faiz Orani Guncellendi")
					.setDescription(`**${type}** faiz orani **%${rate}** olarak ayarlandi.`),
			],
		});
	},

	// Vergi Ayarla
	"vergi-ayarla": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const type = args[0]?.toLowerCase();
		const rate = Number.parseFloat(args[1]);

		if (!type || Number.isNaN(rate) || rate < 0 || rate > 100) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription(
							"Kullanim: `!vergi-ayarla <transfer|gelir> <oran>`",
						),
				],
			});
		}

		const settings = await Settings.getSettings();

		switch (type) {
			case "transfer":
				settings.transferTax = rate;
				break;
			case "gelir":
				settings.incomeTax = rate;
				break;
			default:
				return message.reply({
					embeds: [
						new EmbedBuilder()
							.setColor(config.colors.error)
							.setDescription(
								"Gecersiz vergi turu. Kullanilabilir: transfer, gelir",
							),
					],
				});
		}

		await settings.save();

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Vergi Orani Guncellendi")
					.setDescription(`**${type}** vergisi **%${rate}** olarak ayarlandi.`),
			],
		});
	},

	// Hesap Dondur
	"hesap-dondur": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const target = message.mentions.users.first();
		if (!target) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Kullanim: `!hesap-dondur @kullanici`"),
				],
			});
		}

		const user = await User.findOne({ odgUserI: target.id });
		if (!user) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu kullanicinin banka hesabi yok."),
				],
			});
		}

		user.accountFrozen = true;
		user.frozenAt = new Date();
		user.frozenReason = "Admin tarafindan donduruldu";
		await user.save();

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Hesap Donduruldu")
					.setDescription(
						`**${target.username}** kullanicisinin hesabi donduruldu.`,
					),
			],
		});
	},

	// Hesap Ac
	"hesap-ac": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const target = message.mentions.users.first();
		if (!target) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Kullanim: `!hesap-ac @kullanici`"),
				],
			});
		}

		const user = await User.findOne({ odgUserI: target.id });
		if (!user) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu kullanicinin banka hesabi yok."),
				],
			});
		}

		user.accountFrozen = false;
		user.frozenAt = null;
		user.frozenReason = null;
		await user.save();

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Hesap Acildi")
					.setDescription(
						`**${target.username}** kullanicisinin hesabi acildi.`,
					),
			],
		});
	},

	// Borc Sil
	"borc-sil": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const target = message.mentions.users.first();
		if (!target) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Kullanim: `!borc-sil @kullanici`"),
				],
			});
		}

		const user = await User.findOne({ odgUserI: target.id });
		if (!user) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu kullanicinin banka hesabi yok."),
				],
			});
		}

		const oldDebt = user.creditDebt;
		user.creditDebt = 0;
		user.creditDueDate = null;
		user.creditInterestRate = 0;
		user.totalCreditTaken = 0;
		await user.save();

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Borc Silindi")
					.setDescription(
						`**${target.username}** kullanicisinin **${formatMoney(oldDebt)}** borcu silindi.`,
					),
			],
		});
	},

	// Para Ekle
	"para-ekle": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const target = message.mentions.users.first();
		const amount = Number.parseInt(args[1]);

		if (!target || Number.isNaN(amount) || amount <= 0) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Kullanim: `!para-ekle @kullanici <miktar>`"),
				],
			});
		}

		const user = await User.findOne({ odgUserI: target.id });
		if (!user) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu kullanicinin banka hesabi yok."),
				],
			});
		}

		user.balance += amount;
		await user.save();

		// Log
		await user.addTransaction({
			type: "admin_add",
			amount: amount,
			description: `Admin tarafindan eklendi`,
			balanceAfter: user.balance,
		});

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Para Eklendi")
					.setDescription(
						`**${target.username}** kullanicisina **${formatMoney(amount)}** eklendi.\nYeni bakiye: **${formatMoney(user.balance)}**`,
					),
			],
		});
	},

	// Para Sil
	"para-sil": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const target = message.mentions.users.first();
		const amount = Number.parseInt(args[1]);

		if (!target || Number.isNaN(amount) || amount <= 0) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Kullanim: `!para-sil @kullanici <miktar>`"),
				],
			});
		}

		const user = await User.findOne({ odgUserI: target.id });
		if (!user) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu kullanicinin banka hesabi yok."),
				],
			});
		}

		user.balance = Math.max(0, user.balance - amount);
		await user.save();

		// Log
		await user.addTransaction({
			type: "admin_remove",
			amount: -amount,
			description: `Admin tarafindan silindi`,
			balanceAfter: user.balance,
		});

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Para Silindi")
					.setDescription(
						`**${target.username}** kullanicisinden **${formatMoney(amount)}** silindi.\nYeni bakiye: **${formatMoney(user.balance)}**`,
					),
			],
		});
	},

	// Temerrut Kaldir
	"temerrut-kaldir": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const target = message.mentions.users.first();
		if (!target) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Kullanim: `!temerrut-kaldir @kullanici`"),
				],
			});
		}

		const user = await User.findOne({ odgUserI: target.id });
		if (!user) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu kullanicinin banka hesabi yok."),
				],
			});
		}

		user.defaulted = false;
		user.defaultDays = 0;
		user.defaultStartDate = null;
		user.severeDefault = false;
		await user.save();

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Temerrut Kaldirildi")
					.setDescription(
						`**${target.username}** kullanicisinin temerrut durumu kaldirildi.`,
					),
			],
		});
	},

	// Ekonomi Sifirla
	"ekonomi-sifirla": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const confirm = args[0];
		if (confirm !== "ONAYLA") {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.warning)
						.setTitle("Ekonomi Sifirlama")
						.setDescription(
							"**DIKKAT!** Bu islem tum kullanicilarin verilerini silecektir!\n\nOnaylamak icin: `!ekonomi-sifirla ONAYLA`",
						),
				],
			});
		}

		await User.deleteMany({});
		await Settings.deleteMany({});

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Ekonomi Sifirlandi")
					.setDescription("Tum kullanici verileri silindi."),
			],
		});
	},

	// Ekonomi Rapor
	"ekonomi-rapor": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const totalUsers = await User.countDocuments();
		const activeUsers = await User.countDocuments({ accountFrozen: false });
		const frozenUsers = await User.countDocuments({ accountFrozen: true });
		const defaultedUsers = await User.countDocuments({ defaulted: true });
		const severeDefaultUsers = await User.countDocuments({ severeDefault: true });

		const balanceStats = await User.aggregate([
			{
				$group: {
					_id: null,
					totalBalance: { $sum: "$balance" },
					totalSavings: { $sum: "$savings" },
					totalDebt: { $sum: "$creditDebt" },
					avgBalance: { $avg: "$balance" },
					avgCreditScore: { $avg: "$creditScore" },
					maxBalance: { $max: "$balance" },
					minBalance: { $min: "$balance" },
				},
			},
		]);

		const stats = balanceStats[0] || {
			totalBalance: 0,
			totalSavings: 0,
			totalDebt: 0,
			avgBalance: 0,
			avgCreditScore: 0,
			maxBalance: 0,
			minBalance: 0,
		};

		const jobStats = await User.aggregate([
			{ $group: { _id: "$job", count: { $sum: 1 } } },
			{ $sort: { count: -1 } },
		]);

		const jobList = jobStats
			.map((j) => `${config.jobs[j._id]?.name || "Issiz"}: ${j.count}`)
			.join("\n");

		const embed = new EmbedBuilder()
			.setColor(config.colors.admin)
			.setTitle("Ekonomi Raporu")
			.addFields(
				{
					name: "Kullanici Istatistikleri",
					value: [
						`Toplam: **${totalUsers}**`,
						`Aktif: **${activeUsers}**`,
						`Dondurulmus: **${frozenUsers}**`,
						`Temerrutlu: **${defaultedUsers}**`,
						`Agir Temerrutlu: **${severeDefaultUsers}**`,
					].join("\n"),
					inline: true,
				},
				{
					name: "Finansal Ozet",
					value: [
						`Toplam Bakiye: **${formatMoney(stats.totalBalance)}**`,
						`Toplam Vadeli: **${formatMoney(stats.totalSavings)}**`,
						`Toplam Borc: **${formatMoney(stats.totalDebt)}**`,
						`Net Deger: **${formatMoney(stats.totalBalance + stats.totalSavings - stats.totalDebt)}**`,
					].join("\n"),
					inline: true,
				},
				{
					name: "Ortalamalar",
					value: [
						`Ort. Bakiye: **${formatMoney(Math.round(stats.avgBalance))}**`,
						`Ort. Kredi Notu: **${Math.round(stats.avgCreditScore)}**`,
						`Max Bakiye: **${formatMoney(stats.maxBalance)}**`,
						`Min Bakiye: **${formatMoney(stats.minBalance)}**`,
					].join("\n"),
					inline: true,
				},
				{
					name: "Meslek Dagilimi",
					value: jobList || "Veri yok",
					inline: false,
				},
			)
			.setFooter({ text: `Rapor tarihi` })
			.setTimestamp();

		return message.reply({ embeds: [embed] });
	},

	// Limit Ayarla
	"limit-ayarla": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const type = args[0]?.toLowerCase();
		const amount = Number.parseInt(args[1]);

		if (!type || Number.isNaN(amount) || amount <= 0) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription(
							"Kullanim: `!limit-ayarla <gunluk-transfer|saatlik-transfer|gunluk-kazanc> <miktar>`",
						),
				],
			});
		}

		const settings = await Settings.getSettings();

		switch (type) {
			case "gunluk-transfer":
				settings.dailyTransferLimit = amount;
				break;
			case "saatlik-transfer":
				settings.hourlyTransferLimit = amount;
				break;
			case "gunluk-kazanc":
				settings.dailyEarningLimit = amount;
				break;
			default:
				return message.reply({
					embeds: [
						new EmbedBuilder()
							.setColor(config.colors.error)
							.setDescription(
								"Gecersiz limit turu. Kullanilabilir: gunluk-transfer, saatlik-transfer, gunluk-kazanc",
							),
					],
				});
		}

		await settings.save();

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Limit Guncellendi")
					.setDescription(
						`**${type}** limiti **${formatMoney(amount)}** olarak ayarlandi.`,
					),
			],
		});
	},

	// Kullanici Bilgi
	"kullanici-bilgi": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const target = message.mentions.users.first();
		if (!target) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Kullanim: `!kullanici-bilgi @kullanici`"),
				],
			});
		}

		const user = await User.findOne({ odgUserI: target.id });
		if (!user) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu kullanicinin banka hesabi yok."),
				],
			});
		}

		const job = config.jobs[user.job] || { name: "Issiz", salary: 0 };
		const accountAge = Math.floor(
			(Date.now() - new Date(user.createdAt).getTime()) / (1000 * 60 * 60 * 24),
		);

		const embed = new EmbedBuilder()
			.setColor(config.colors.admin)
			.setTitle(`Kullanici Bilgisi: ${target.username}`)
			.setThumbnail(target.displayAvatarURL())
			.addFields(
				{
					name: "Hesap Bilgileri",
					value: [
						`IBAN: \`${user.iban}\``,
						`Hesap Yasi: **${accountAge} gun**`,
						`Meslek: **${job.name}**`,
						`Level: **${user.level}**`,
						`XP: **${user.xp}/${user.level * 1000}**`,
					].join("\n"),
					inline: true,
				},
				{
					name: "Finansal Durum",
					value: [
						`Bakiye: **${formatMoney(user.balance)}**`,
						`Vadeli: **${formatMoney(user.savings)}**`,
						`Kredi Borcu: **${formatMoney(user.creditDebt)}**`,
						`Kredi Notu: **${user.creditScore}**`,
					].join("\n"),
					inline: true,
				},
				{
					name: "Durum",
					value: [
						`Hesap: **${user.accountFrozen ? "Dondurulmus" : "Aktif"}**`,
						`Temerrut: **${user.defaulted ? "Evet" : "Hayir"}**`,
						`Temerrut Gun: **${user.defaultDays}**`,
						`Agir Temerrut: **${user.severeDefault ? "Evet" : "Hayir"}**`,
					].join("\n"),
					inline: true,
				},
				{
					name: "Islem Gecmisi (Son 5)",
					value:
						user.transactions
							.slice(-5)
							.reverse()
							.map(
								(t) =>
									`${t.type}: ${formatMoney(t.amount)} - ${new Date(t.date).toLocaleDateString("tr-TR")}`,
							)
							.join("\n") || "Islem yok",
					inline: false,
				},
			)
			.setTimestamp();

		return message.reply({ embeds: [embed] });
	},

	// Kredi Notu Ayarla
	"not-ayarla": async (message, args) => {
		if (!isAdmin(message.author.username)) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu komutu kullanma yetkiniz yok."),
				],
			});
		}

		const target = message.mentions.users.first();
		const score = Number.parseInt(args[1]);

		if (!target || Number.isNaN(score) || score < 0 || score > 2000) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription(
							"Kullanim: `!not-ayarla @kullanici <0-2000>`",
						),
				],
			});
		}

		const user = await User.findOne({ odgUserI: target.id });
		if (!user) {
			return message.reply({
				embeds: [
					new EmbedBuilder()
						.setColor(config.colors.error)
						.setDescription("Bu kullanicinin banka hesabi yok."),
				],
			});
		}

		const oldScore = user.creditScore;
		user.creditScore = score;
		await user.save();

		return message.reply({
			embeds: [
				new EmbedBuilder()
					.setColor(config.colors.success)
					.setTitle("Kredi Notu Guncellendi")
					.setDescription(
						`**${target.username}** kullanicisinin kredi notu **${oldScore}** -> **${score}** olarak guncellendi.`,
					),
			],
		});
	},
};
