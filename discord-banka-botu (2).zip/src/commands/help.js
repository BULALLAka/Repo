/**
 * Yardim Komutlari
 */

const { EmbedBuilder } = require("discord.js");
const config = require("../config/config");

module.exports = {
	// Ana Yardim
	yardim: async (message, args) => {
		const category = args[0]?.toLowerCase();

		if (!category) {
			const embed = new EmbedBuilder()
				.setColor(config.colors.primary)
				.setTitle("Banka Bot Yardim Menusu")
				.setDescription(
					"Detayli bilgi icin: `!yardim <kategori>`",
				)
				.addFields(
					{
						name: "Hesap",
						value: "`!yardim hesap`\nHesap olusturma ve yonetim",
						inline: true,
					},
					{
						name: "Banka",
						value: "`!yardim banka`\nPara yatirma, cekme, transfer",
						inline: true,
					},
					{
						name: "Calisma",
						value: "`!yardim calisma`\nMeslek ve maas sistemi",
						inline: true,
					},
					{
						name: "Vadeli",
						value: "`!yardim vadeli`\nVadeli hesap islemleri",
						inline: true,
					},
					{
						name: "Kredi",
						value: "`!yardim kredi`\nKredi cekme ve odeme",
						inline: true,
					},
					{
						name: "Fatura",
						value: "`!yardim fatura`\nFatura odeme sistemi",
						inline: true,
					},
					{
						name: "Siralama",
						value: "`!yardim siralama`\nLider tablolari",
						inline: true,
					},
					{
						name: "Temerrut",
						value: "`!yardim temerrut`\nTemerrut ve yapilandirma",
						inline: true,
					},
				)
				.setFooter({ text: "Prefix: !" })
				.setTimestamp();

			return message.reply({ embeds: [embed] });
		}

		let embed;

		switch (category) {
			case "hesap":
				embed = new EmbedBuilder()
					.setColor(config.colors.primary)
					.setTitle("Hesap Komutlari")
					.addFields(
						{
							name: "!hesap-olustur",
							value: "Yeni banka hesabi olusturur\nHer kullanicinin sadece 1 hesabi olabilir",
							inline: false,
						},
						{
							name: "!para / !bakiye",
							value: "Hesap bilgilerinizi gosterir\nBakiye, vadeli, borc, kredi notu vb.",
							inline: false,
						},
						{
							name: "!hesap-bilgi",
							value: "Detayli hesap bilgileri\nIBAN, hesap yasi, islem gecmisi",
							inline: false,
						},
						{
							name: "!islemler",
							value: "Son islemlerinizi listeler",
							inline: false,
						},
					);
				break;

			case "banka":
				embed = new EmbedBuilder()
					.setColor(config.colors.primary)
					.setTitle("Banka Islemleri")
					.addFields(
						{
							name: "!yatir <miktar>",
							value: "Bankaya para yatirir\nOrnek: `!yatir 1000`",
							inline: false,
						},
						{
							name: "!cek <miktar>",
							value: "Bankadan para ceker\nOrnek: `!cek 500`",
							inline: false,
						},
						{
							name: "!transfer @kisi <miktar>",
							value: "Baska kullaniciya para gonderir\n%2 transfer vergisi kesilir\nOrnek: `!transfer @ahmet 1000`",
							inline: false,
						},
						{
							name: "!iban-transfer <IBAN> <miktar>",
							value: "IBAN ile para gonderir\nOrnek: `!iban-transfer TR123456 1000`",
							inline: false,
						},
						{
							name: "Limitler",
							value: "Gunluk transfer limiti: 50.000 TL\nSaatlik transfer limiti: 10.000 TL",
							inline: false,
						},
					);
				break;

			case "calisma":
				embed = new EmbedBuilder()
					.setColor(config.colors.primary)
					.setTitle("Calisma Sistemi")
					.addFields(
						{
							name: "!calis",
							value: "Calisarak para kazanir\n30 dakika bekleme suresi\nMeslege gore kazanc degisir",
							inline: false,
						},
						{
							name: "!meslek-sec <meslek>",
							value: "Meslek secer\nMeslekler: memur, yazilimci, esnaf, yonetici, bankaci, freelancer",
							inline: false,
						},
						{
							name: "!meslekler",
							value: "Tum meslekleri ve maaslarini listeler",
							inline: false,
						},
						{
							name: "!maas-al",
							value: "Gunluk maasini alir\n24 saat bekleme suresi\nTemerrutteysen %30 kesilir",
							inline: false,
						},
					);
				break;

			case "vadeli":
				embed = new EmbedBuilder()
					.setColor(config.colors.primary)
					.setTitle("Vadeli Hesap")
					.addFields(
						{
							name: "!vadeli-ac <miktar> <7|14|30>",
							value: "Vadeli hesap acar\n7 gun: %3 faiz\n14 gun: %6 faiz\n30 gun: %12 faiz\nOrnek: `!vadeli-ac 10000 30`",
							inline: false,
						},
						{
							name: "!vadeli-durum",
							value: "Vadeli hesap durumunu gosterir\nKalan sure ve beklenen faiz",
							inline: false,
						},
						{
							name: "!vadeli-boz",
							value: "Vadeli hesabi erken bozar\n%5 ceza kesilir",
							inline: false,
						},
					);
				break;

			case "kredi":
				embed = new EmbedBuilder()
					.setColor(config.colors.primary)
					.setTitle("Kredi Sistemi")
					.addFields(
						{
							name: "!kredi-cek <miktar>",
							value: "Kredi ceker\nLimit: Level, meslek ve kredi notuna gore\nFaiz orani dinamik\nOrnek: `!kredi-cek 5000`",
							inline: false,
						},
						{
							name: "!kredi-ode <miktar>",
							value: "Kredi borcunu oder\nOrnek: `!kredi-ode 2000`",
							inline: false,
						},
						{
							name: "!kredi-durum",
							value: "Kredi durumunu gosterir\nBorc, faiz, son odeme tarihi",
							inline: false,
						},
						{
							name: "Kredi Notu",
							value: "Baslangic: 1000\nDuzenli odeme arttirir\nGecikme dusurur\n500 altinda kredi yasak",
							inline: false,
						},
					);
				break;

			case "fatura":
				embed = new EmbedBuilder()
					.setColor(config.colors.primary)
					.setTitle("Fatura Sistemi")
					.addFields(
						{
							name: "!faturalar",
							value: "Bekleyen faturalarinizi gosterir",
							inline: false,
						},
						{
							name: "!fatura-ode <tur>",
							value: "Fatura oder\nTurler: elektrik, internet, su, telefon\nOrnek: `!fatura-ode elektrik`",
							inline: false,
						},
						{
							name: "!tum-faturalar-ode",
							value: "Tum faturalari tek seferde oder",
							inline: false,
						},
						{
							name: "Onemli",
							value: "Faturalar aylik otomatik gelir\nOdemezsen kredi notu duser",
							inline: false,
						},
					);
				break;

			case "siralama":
				embed = new EmbedBuilder()
					.setColor(config.colors.primary)
					.setTitle("Lider Tablolari")
					.addFields(
						{
							name: "!zenginler",
							value: "En zengin kullanicilari listeler\nToplam varlik siralamasi",
							inline: false,
						},
						{
							name: "!en-cok-borc",
							value: "En borcu kullanicilari listeler",
							inline: false,
						},
						{
							name: "!en-iyi-not",
							value: "En yuksek kredi notuna sahip kullanicilari listeler",
							inline: false,
						},
						{
							name: "!en-caliskan",
							value: "En cok calisanlari listeler",
							inline: false,
						},
					);
				break;

			case "temerrut":
				embed = new EmbedBuilder()
					.setColor(config.colors.primary)
					.setTitle("Temerrut Sistemi")
					.addFields(
						{
							name: "Temerrut Nedir?",
							value: "Kredi borcunu zamaninda odemezsen temerrute dusersin",
							inline: false,
						},
						{
							name: "!temerrut-durum",
							value: "Temerrut durumunuzu gosterir",
							inline: false,
						},
						{
							name: "Temerrut Asalamalari",
							value: [
								"**1-6 gun:** Normal temerrut",
								"- %10 gecikme cezasi",
								"- Gunluk %1 faiz",
								"- Maas kesintisi %30",
								"",
								"**7-13 gun:** Agir temerrut",
								"- Transfer yasagi",
								"- Yeni kredi yasagi",
								"",
								"**14+ gun:** Hesap dondurma",
								"- Tum islemler yasakli",
							].join("\n"),
							inline: false,
						},
						{
							name: "!borc-yapilandir",
							value: "Borcunuzu yapilandirarak taksitlendirir\nFaiz duser, temerrut kalkar",
							inline: false,
						},
					);
				break;

			default:
				return message.reply({
					embeds: [
						new EmbedBuilder()
							.setColor(config.colors.error)
							.setDescription(
								"Gecersiz kategori. Kullanilabilir: hesap, banka, calisma, vadeli, kredi, fatura, siralama, temerrut",
							),
					],
				});
		}

		return message.reply({ embeds: [embed] });
	},

	// Kisa yardim aliasi
	help: async (message, args) => {
		return module.exports.yardim(message, args);
	},

	// Komutlar listesi
	komutlar: async (message, args) => {
		const embed = new EmbedBuilder()
			.setColor(config.colors.primary)
			.setTitle("Tum Komutlar")
			.setDescription("Detayli bilgi icin: `!yardim`")
			.addFields(
				{
					name: "Hesap",
					value: "`hesap-olustur` `para` `bakiye` `hesap-bilgi` `islemler`",
					inline: false,
				},
				{
					name: "Banka",
					value: "`yatir` `cek` `transfer` `iban-transfer`",
					inline: false,
				},
				{
					name: "Calisma",
					value: "`calis` `meslek-sec` `meslekler` `maas-al`",
					inline: false,
				},
				{
					name: "Vadeli",
					value: "`vadeli-ac` `vadeli-durum` `vadeli-boz`",
					inline: false,
				},
				{
					name: "Kredi",
					value: "`kredi-cek` `kredi-ode` `kredi-durum`",
					inline: false,
				},
				{
					name: "Fatura",
					value: "`faturalar` `fatura-ode` `tum-faturalar-ode`",
					inline: false,
				},
				{
					name: "Temerrut",
					value: "`temerrut-durum` `borc-yapilandir`",
					inline: false,
				},
				{
					name: "Siralama",
					value: "`zenginler` `en-cok-borc` `en-iyi-not` `en-caliskan`",
					inline: false,
				},
			)
			.setFooter({ text: "Prefix: !" })
			.setTimestamp();

		return message.reply({ embeds: [embed] });
	},
};
