/**
 * ========================================
 * HESAP KOMUTLARI
 * ========================================
 * !hesap-olustur, !hesap, !para, !bakiye
 */

const { EmbedBuilder } = require('discord.js');
const User = require('../models/User');
const config = require('../config/config');
const {
    formatMoney,
    formatDate,
    formatIBAN,
    createProgressBar,
    getCreditScoreRating,
    getAccountStatusEmoji,
    getAccountStatusText,
    getJobEmoji,
    createSuccessEmbed,
    createErrorEmbed,
    createBankEmbed,
    getXPForLevel
} = require('../utils/helpers');

/**
 * Hesap Oluştur
 */
async function hesapOlustur(message) {
    const existingUser = await User.findOne({ odUserId: message.author.id });
    
    if (existingUser) {
        const embed = createErrorEmbed(
            'Hesap Mevcut',
            `Zaten bir banka hesabınız var!\n\n` +
            `**IBAN:** \`${formatIBAN(existingUser.iban)}\`\n` +
            `**Bakiye:** ${formatMoney(existingUser.balance)}\n\n` +
            `Bakiyenizi görmek için \`!para\` yazın.`
        );
        return message.reply({ embeds: [embed] });
    }
    
    // Hesap yaşı kontrolü (anti-alt)
    const accountAge = (Date.now() - message.author.createdTimestamp) / (1000 * 60 * 60 * 24);
    if (accountAge < config.security.minAccountAge) {
        const embed = createErrorEmbed(
            'Hesap Çok Yeni',
            `Discord hesabınız en az **${config.security.minAccountAge} gün** eski olmalı.\n` +
            `Hesap yaşınız: **${Math.floor(accountAge)} gün**`
        );
        return message.reply({ embeds: [embed] });
    }
    
    // Yeni IBAN oluştur
    const iban = User.generateIBAN();
    
    // Yeni kullanıcı oluştur
    const newUser = new User({
        odUserId: message.author.id,
        username: message.author.username,
        iban: iban,
        balance: 1000, // Başlangıç bonusu
        creditScore: config.creditScore.initial
    });
    
    // Hoşgeldin işlemi ekle
    newUser.addTransaction('admin', 1000, 'Hoşgeldin bonusu');
    
    await newUser.save();
    
    const embed = new EmbedBuilder()
        .setColor(config.colors.success)
        .setTitle('🏦 Banka Hesabı Oluşturuldu!')
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setDescription(
            `Hoş geldiniz **${message.author.username}**!\n` +
            `Global Banka ailesine katıldınız.`
        )
        .addFields(
            { name: '🆔 IBAN', value: `\`${formatIBAN(iban)}\``, inline: false },
            { name: '💰 Başlangıç Bakiyesi', value: formatMoney(1000), inline: true },
            { name: '📊 Kredi Notu', value: `${config.creditScore.initial}`, inline: true },
            { name: '📈 Seviye', value: '1', inline: true }
        )
        .addFields(
            { name: '📋 Başlangıç Rehberi', value: 
                `• \`!para\` - Bakiyenizi görün\n` +
                `• \`!meslek-sec\` - Meslek seçin\n` +
                `• \`!calis\` - Çalışarak para kazanın\n` +
                `• \`!maas-al\` - Günlük maaşınızı alın\n` +
                `• \`!yardim\` - Tüm komutlar`
            }
        )
        .setFooter({ text: 'Global Banka Sistemi • Hesabınız tüm sunucularda geçerlidir' })
        .setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Para / Bakiye Görüntüle
 */
async function para(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        const embed = createErrorEmbed(
            'Hesap Bulunamadı',
            'Henüz bir banka hesabınız yok!\n`!hesap-olustur` yazarak hesap açabilirsiniz.'
        );
        return message.reply({ embeds: [embed] });
    }
    
    const totalSavings = user.getTotalSavings();
    const totalAssets = user.getTotalAssets();
    const netWorth = user.getNetWorth();
    const creditRating = getCreditScoreRating(user.creditScore);
    const xpNeeded = getXPForLevel(user.level);
    const xpProgress = createProgressBar(user.xp, xpNeeded, 10);
    
    const embed = new EmbedBuilder()
        .setColor(user.defaulted ? config.colors.error : config.colors.bank)
        .setTitle(`🏦 ${message.author.username} - Banka Hesabı`)
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .addFields(
            { name: '💵 Vadesiz Bakiye', value: formatMoney(user.balance), inline: true },
            { name: '💎 Vadeli Bakiye', value: formatMoney(totalSavings), inline: true },
            { name: '📊 Toplam Varlık', value: formatMoney(totalAssets), inline: true },
            
            { name: '💳 Kredi Borcu', value: user.creditDebt > 0 ? formatMoney(user.creditDebt) : 'Yok', inline: true },
            { name: '💰 Net Değer', value: formatMoney(netWorth), inline: true },
            { name: '\u200b', value: '\u200b', inline: true },
            
            { name: `${creditRating.emoji} Kredi Notu`, value: `${user.creditScore} (${creditRating.rating})`, inline: true },
            { name: `${getJobEmoji(user.job)} Meslek`, value: user.job.charAt(0).toUpperCase() + user.job.slice(1), inline: true },
            { name: `${getAccountStatusEmoji(user.accountStatus)} Hesap Durumu`, value: getAccountStatusText(user.accountStatus), inline: true },
            
            { name: `📈 Seviye ${user.level}`, value: `${xpProgress} ${user.xp}/${xpNeeded} XP`, inline: false }
        );
    
    // Temerrüt durumu varsa uyarı ekle
    if (user.defaulted) {
        const defaultDays = user.calculateDefaultDays();
        embed.addFields({
            name: '⚠️ TEMERRÜT DURUMU',
            value: `**${defaultDays} gün** boyunca borcunuzu ödemediniz!\n` +
                   `Günlük %1 faiz işlemektedir.\n` +
                   `\`!temerrut-durum\` ile detayları görün.`,
            inline: false
        });
    }
    
    // Ödenmemiş fatura varsa
    const unpaidBills = user.bills.filter(b => !b.paid);
    if (unpaidBills.length > 0) {
        embed.addFields({
            name: '📄 Ödenmemiş Faturalar',
            value: `${unpaidBills.length} adet faturanız var.\n\`!faturalar\` ile görüntüleyin.`,
            inline: false
        });
    }
    
    embed.addFields({
        name: '🆔 IBAN',
        value: `\`${formatIBAN(user.iban)}\``,
        inline: false
    });
    
    embed.setFooter({ 
        text: `Hesap Açılış: ${formatDate(user.createdAt)} • Global Banka` 
    });
    embed.setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Detaylı Hesap Bilgisi
 */
async function hesap(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        const embed = createErrorEmbed(
            'Hesap Bulunamadı',
            'Henüz bir banka hesabınız yok!\n`!hesap-olustur` yazarak hesap açabilirsiniz.'
        );
        return message.reply({ embeds: [embed] });
    }
    
    const creditRating = getCreditScoreRating(user.creditScore);
    const creditLimit = user.getCreditLimit(config);
    const interestRate = user.getInterestRate(config);
    const transferLimit = user.getTransferLimit(config);
    
    const embed = new EmbedBuilder()
        .setColor(config.colors.bank)
        .setTitle(`📋 ${message.author.username} - Detaylı Hesap Bilgisi`)
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .addFields(
            { name: '🆔 IBAN', value: `\`${formatIBAN(user.iban)}\``, inline: false },
            
            { name: '📊 Finansal Durum', value: 
                `💵 Vadesiz: ${formatMoney(user.balance)}\n` +
                `💎 Vadeli: ${formatMoney(user.getTotalSavings())}\n` +
                `💳 Borç: ${formatMoney(user.creditDebt)}\n` +
                `💰 Net: ${formatMoney(user.getNetWorth())}`,
                inline: true 
            },
            
            { name: '📈 Seviye & XP', value: 
                `🎯 Seviye: ${user.level}\n` +
                `✨ XP: ${user.xp}/${getXPForLevel(user.level)}\n` +
                `${getJobEmoji(user.job)} Meslek: ${user.job}`,
                inline: true 
            },
            
            { name: `${creditRating.emoji} Kredi Bilgileri`, value: 
                `📊 Kredi Notu: ${user.creditScore}\n` +
                `💳 Kredi Limiti: ${formatMoney(creditLimit)}\n` +
                `📈 Faiz Oranı: %${(interestRate * 100).toFixed(1)}`,
                inline: true 
            },
            
            { name: '🔄 Limitler', value: 
                `📤 Günlük Transfer: ${formatMoney(user.dailyTransfers)}/${formatMoney(transferLimit)}\n` +
                `⏰ Saatlik Transfer: ${formatMoney(user.hourlyTransfers)}/${formatMoney(config.transfer.hourlyLimit)}\n` +
                `💵 Günlük Kazanç: ${formatMoney(user.dailyEarnings)}/${formatMoney(config.security.dailyEarningLimit)}`,
                inline: false 
            },
            
            { name: '📊 İstatistikler', value: 
                `💰 Toplam Kazanç: ${formatMoney(user.stats.totalEarned)}\n` +
                `💸 Toplam Harcama: ${formatMoney(user.stats.totalSpent)}\n` +
                `🔄 Gönderilen: ${formatMoney(user.stats.totalTransferred)}\n` +
                `📥 Alınan: ${formatMoney(user.stats.totalReceived)}\n` +
                `💳 Ödenen Kredi: ${formatMoney(user.stats.creditsRepaid)}\n` +
                `🔧 Çalışma: ${user.stats.workCount} kez`,
                inline: false 
            },
            
            { name: '📅 Tarihler', value: 
                `🏦 Hesap Açılış: ${formatDate(user.createdAt)}\n` +
                `🕐 Son Aktivite: ${formatDate(user.lastActive)}`,
                inline: false 
            }
        )
        .setFooter({ text: 'Global Banka Sistemi' })
        .setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * IBAN Sorgula
 */
async function iban(message, args) {
    // Kendi IBAN'ını göster
    if (!args[0]) {
        const user = await User.findOne({ odUserId: message.author.id });
        
        if (!user) {
            return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
        }
        
        const embed = createBankEmbed('IBAN Bilgisi')
            .setDescription(`**Sizin IBAN'ınız:**\n\`${formatIBAN(user.iban)}\``)
            .addFields({ name: '📋 Kopyalamak için:', value: `\`${user.iban}\`` });
        
        return message.reply({ embeds: [embed] });
    }
    
    // Başka birinin IBAN'ını sorgula
    const targetId = args[0].replace(/[<@!>]/g, '');
    const targetUser = await User.findOne({ odUserId: targetId });
    
    if (!targetUser) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Bu kullanıcının banka hesabı yok.')] });
    }
    
    const embed = createBankEmbed('IBAN Sorgusu')
        .setDescription(`**${targetUser.username}** kullanıcısının IBAN'ı:\n\`${formatIBAN(targetUser.iban)}\``);
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    hesapOlustur,
    para,
    hesap,
    iban,
    // Alias'lar
    bakiye: para
};
