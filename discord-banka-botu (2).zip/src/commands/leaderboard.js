/**
 * ========================================
 * LİDERLİK TABLOSU KOMUTLARI
 * ========================================
 * !zenginler, !en-cok-borc, !en-iyi-not, !seviye-sirala
 */

const { EmbedBuilder } = require('discord.js');
const User = require('../models/User');
const config = require('../config/config');
const {
    formatMoney,
    abbreviateNumber,
    createBankEmbed,
    getCreditScoreRating
} = require('../utils/helpers');

/**
 * En Zenginler
 */
async function zenginler(message, args) {
    const page = parseInt(args[0]) || 1;
    const pageSize = config.leaderboard.pageSize;
    const skip = (page - 1) * pageSize;
    
    const totalUsers = await User.countDocuments({ accountStatus: { $ne: 'closed' } });
    const totalPages = Math.ceil(totalUsers / pageSize);
    
    if (page > totalPages && totalPages > 0) {
        return message.reply({ embeds: [createBankEmbed('Sayfa Bulunamadı').setDescription(`Toplam ${totalPages} sayfa var.`)] });
    }
    
    // Toplam varlığa göre sırala (balance + savings)
    const users = await User.aggregate([
        { $match: { accountStatus: { $ne: 'closed' } } },
        {
            $addFields: {
                totalSavings: {
                    $sum: {
                        $map: {
                            input: { $filter: { input: '$savingsAccounts', cond: { $eq: ['$$this.status', 'active'] } } },
                            in: '$$this.amount'
                        }
                    }
                }
            }
        },
        {
            $addFields: {
                totalAssets: { $add: ['$balance', '$totalSavings'] }
            }
        },
        { $sort: { totalAssets: -1 } },
        { $skip: skip },
        { $limit: pageSize }
    ]);
    
    const embed = createBankEmbed('🏆 En Zenginler')
        .setDescription(`Toplam varlığa göre global sıralama\nSayfa ${page}/${totalPages || 1}`);
    
    if (users.length === 0) {
        embed.addFields({ name: 'Boş', value: 'Henüz kullanıcı yok.', inline: false });
    } else {
        let leaderboard = '';
        users.forEach((user, index) => {
            const rank = skip + index + 1;
            const medal = rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : `**${rank}.**`;
            const isRequester = user.odUserId === message.author.id;
            const highlight = isRequester ? ' ⬅️' : '';
            
            leaderboard += `${medal} ${user.username}${highlight}\n`;
            leaderboard += `   💰 ${formatMoney(user.totalAssets)} (Bakiye: ${abbreviateNumber(user.balance)})\n\n`;
        });
        
        embed.addFields({ name: '📊 Sıralama', value: leaderboard, inline: false });
    }
    
    // Kullanıcının kendi sırası
    const userRank = await User.aggregate([
        { $match: { accountStatus: { $ne: 'closed' } } },
        {
            $addFields: {
                totalSavings: {
                    $sum: {
                        $map: {
                            input: { $filter: { input: '$savingsAccounts', cond: { $eq: ['$$this.status', 'active'] } } },
                            in: '$$this.amount'
                        }
                    }
                }
            }
        },
        { $addFields: { totalAssets: { $add: ['$balance', '$totalSavings'] } } },
        { $sort: { totalAssets: -1 } },
        { $group: { _id: null, users: { $push: '$odUserId' } } },
        { $project: { rank: { $add: [{ $indexOfArray: ['$users', message.author.id] }, 1] } } }
    ]);
    
    if (userRank.length > 0 && userRank[0].rank > 0) {
        embed.setFooter({ text: `Senin sıran: #${userRank[0].rank} / ${totalUsers} • Sayfa: ${page}/${totalPages || 1}` });
    }
    
    return message.reply({ embeds: [embed] });
}

/**
 * En Çok Borçlular
 */
async function enCokBorc(message, args) {
    const page = parseInt(args[0]) || 1;
    const pageSize = config.leaderboard.pageSize;
    const skip = (page - 1) * pageSize;
    
    const users = await User.find({ creditDebt: { $gt: 0 } })
        .sort({ creditDebt: -1 })
        .skip(skip)
        .limit(pageSize)
        .lean();
    
    const totalUsers = await User.countDocuments({ creditDebt: { $gt: 0 } });
    const totalPages = Math.ceil(totalUsers / pageSize);
    
    const embed = createBankEmbed('💳 En Çok Borçlular')
        .setDescription(`Kredi borcuna göre sıralama\nSayfa ${page}/${totalPages || 1}`);
    
    if (users.length === 0) {
        embed.addFields({ name: '✅ Temiz!', value: 'Kimsenin kredi borcu yok!', inline: false });
    } else {
        let leaderboard = '';
        users.forEach((user, index) => {
            const rank = skip + index + 1;
            const isDefaulted = user.defaulted ? '🔴' : '🟡';
            const isRequester = user.odUserId === message.author.id;
            const highlight = isRequester ? ' ⬅️' : '';
            
            leaderboard += `**${rank}.** ${isDefaulted} ${user.username}${highlight}\n`;
            leaderboard += `   💳 ${formatMoney(user.creditDebt)}\n\n`;
        });
        
        embed.addFields({ name: '📊 Sıralama', value: leaderboard, inline: false });
    }
    
    return message.reply({ embeds: [embed] });
}

/**
 * En İyi Kredi Notları
 */
async function enIyiNot(message, args) {
    const page = parseInt(args[0]) || 1;
    const pageSize = config.leaderboard.pageSize;
    const skip = (page - 1) * pageSize;
    
    const users = await User.find({ accountStatus: { $ne: 'closed' } })
        .sort({ creditScore: -1 })
        .skip(skip)
        .limit(pageSize)
        .lean();
    
    const totalUsers = await User.countDocuments({ accountStatus: { $ne: 'closed' } });
    const totalPages = Math.ceil(totalUsers / pageSize);
    
    const embed = createBankEmbed('⭐ En İyi Kredi Notları')
        .setDescription(`Kredi notuna göre sıralama\nSayfa ${page}/${totalPages || 1}`);
    
    if (users.length === 0) {
        embed.addFields({ name: 'Boş', value: 'Henüz kullanıcı yok.', inline: false });
    } else {
        let leaderboard = '';
        users.forEach((user, index) => {
            const rank = skip + index + 1;
            const rating = getCreditScoreRating(user.creditScore);
            const medal = rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : `**${rank}.**`;
            const isRequester = user.odUserId === message.author.id;
            const highlight = isRequester ? ' ⬅️' : '';
            
            leaderboard += `${medal} ${user.username}${highlight}\n`;
            leaderboard += `   ${rating.emoji} ${user.creditScore} (${rating.rating})\n\n`;
        });
        
        embed.addFields({ name: '📊 Sıralama', value: leaderboard, inline: false });
    }
    
    return message.reply({ embeds: [embed] });
}

/**
 * Seviye Sıralaması
 */
async function seviyeSirala(message, args) {
    const page = parseInt(args[0]) || 1;
    const pageSize = config.leaderboard.pageSize;
    const skip = (page - 1) * pageSize;
    
    const users = await User.find({ accountStatus: { $ne: 'closed' } })
        .sort({ level: -1, xp: -1 })
        .skip(skip)
        .limit(pageSize)
        .lean();
    
    const totalUsers = await User.countDocuments({ accountStatus: { $ne: 'closed' } });
    const totalPages = Math.ceil(totalUsers / pageSize);
    
    const embed = createBankEmbed('📈 Seviye Sıralaması')
        .setDescription(`Seviye ve XP'ye göre sıralama\nSayfa ${page}/${totalPages || 1}`);
    
    if (users.length === 0) {
        embed.addFields({ name: 'Boş', value: 'Henüz kullanıcı yok.', inline: false });
    } else {
        let leaderboard = '';
        users.forEach((user, index) => {
            const rank = skip + index + 1;
            const medal = rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : `**${rank}.**`;
            const isRequester = user.odUserId === message.author.id;
            const highlight = isRequester ? ' ⬅️' : '';
            
            leaderboard += `${medal} ${user.username}${highlight}\n`;
            leaderboard += `   📊 Seviye ${user.level} | ✨ ${user.xp} XP\n\n`;
        });
        
        embed.addFields({ name: '📊 Sıralama', value: leaderboard, inline: false });
    }
    
    return message.reply({ embeds: [embed] });
}

/**
 * Global İstatistikler
 */
async function globalStats(message) {
    const stats = await User.aggregate([
        { $match: { accountStatus: { $ne: 'closed' } } },
        {
            $group: {
                _id: null,
                totalUsers: { $sum: 1 },
                totalBalance: { $sum: '$balance' },
                totalDebt: { $sum: '$creditDebt' },
                avgCreditScore: { $avg: '$creditScore' },
                avgLevel: { $avg: '$level' },
                totalDefaulted: { $sum: { $cond: ['$defaulted', 1, 0] } }
            }
        }
    ]);
    
    const data = stats[0] || {
        totalUsers: 0,
        totalBalance: 0,
        totalDebt: 0,
        avgCreditScore: 0,
        avgLevel: 0,
        totalDefaulted: 0
    };
    
    const embed = createBankEmbed('🌍 Global Ekonomi İstatistikleri')
        .addFields(
            { name: '👥 Toplam Kullanıcı', value: data.totalUsers.toString(), inline: true },
            { name: '💰 Toplam Para', value: formatMoney(data.totalBalance), inline: true },
            { name: '💳 Toplam Borç', value: formatMoney(data.totalDebt), inline: true },
            { name: '📊 Ort. Kredi Notu', value: Math.round(data.avgCreditScore).toString(), inline: true },
            { name: '📈 Ort. Seviye', value: Math.round(data.avgLevel).toString(), inline: true },
            { name: '🔴 Temerrüt Sayısı', value: data.totalDefaulted.toString(), inline: true }
        )
        .setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    zenginler,
    enCokBorc,
    enIyiNot,
    seviyeSirala,
    globalStats
};
