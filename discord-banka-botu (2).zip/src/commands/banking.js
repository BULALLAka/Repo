/**
 * ========================================
 * BANKA İŞLEMLERİ KOMUTLARI
 * ========================================
 * !yatir, !cek, !transfer
 */

const { EmbedBuilder } = require('discord.js');
const User = require('../models/User');
const config = require('../config/config');
const {
    formatMoney,
    formatPercent,
    parseAmount,
    extractUserId,
    createSuccessEmbed,
    createErrorEmbed,
    createBankEmbed,
    formatIBAN
} = require('../utils/helpers');

/**
 * Para Yatır
 */
async function yatir(message, args) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (user.accountStatus === 'frozen') {
        return message.reply({ embeds: [createErrorEmbed('Hesap Dondurulmuş', 'Hesabınız dondurulmuş durumda. İşlem yapamazsınız.')] });
    }
    
    const amount = parseAmount(args[0], user.balance);
    
    if (!amount || amount <= 0) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Miktar', 'Lütfen geçerli bir miktar girin.\nÖrnek: `!yatir 1000` veya `!yatir 1k`')] });
    }
    
    // Bakiye yeterli olduğu için doğrudan yatır (vadesiz'den vadeli'ye değil, dışarıdan yatırma simülasyonu)
    // Bu basit versiyonda "yatırma" işlemi sadece bakiyeyi artırır (gerçek hayatta ATM/banka şubesi)
    // Ancak bot ekonomisinde bu mantıklı değil, o yüzden bu komutu "cüzdandan bankaya" olarak yorumlayalım
    
    const embed = createSuccessEmbed(
        'Para Yatırıldı',
        `**${formatMoney(amount)}** hesabınıza yatırıldı.\n\n` +
        `💵 Yeni Bakiye: **${formatMoney(user.balance + amount)}**`
    );
    
    // Not: Gerçek bot ekonomisinde bu komut genelde devre dışı bırakılır
    // Çünkü para "nereden" geliyor belirsiz. Bunun yerine !calis ve !maas-al kullanılır.
    // Bu örnekte komutu bilgilendirme amaçlı bırakıyorum:
    
    const infoEmbed = createBankEmbed('Para Yatırma Bilgisi')
        .setDescription(
            'Bot ekonomisinde para yatırma işlemi bulunmamaktadır.\n\n' +
            '**Para kazanmak için:**\n' +
            '• `!calis` - Çalışarak para kazanın\n' +
            '• `!maas-al` - Günlük maaşınızı alın\n' +
            '• `!meslek-sec` - Daha iyi maaş için meslek seçin'
        );
    
    return message.reply({ embeds: [infoEmbed] });
}

/**
 * Para Çek
 */
async function cek(message, args) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (user.accountStatus === 'frozen') {
        return message.reply({ embeds: [createErrorEmbed('Hesap Dondurulmuş', 'Hesabınız dondurulmuş durumda. İşlem yapamazsınız.')] });
    }
    
    const amount = parseAmount(args[0], user.balance);
    
    if (!amount || amount <= 0) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Miktar', 'Lütfen geçerli bir miktar girin.\nÖrnek: `!cek 1000` veya `!cek all`')] });
    }
    
    if (amount > user.balance) {
        return message.reply({ embeds: [createErrorEmbed('Yetersiz Bakiye', `Bakiyeniz: ${formatMoney(user.balance)}\nÇekmek istediğiniz: ${formatMoney(amount)}`)] });
    }
    
    // Çekim vergisi
    const tax = Math.floor(amount * config.taxes.withdrawal);
    const netAmount = amount - tax;
    
    user.balance -= amount;
    user.stats.totalSpent += amount;
    user.addTransaction('withdraw', amount, `Para çekme (Vergi: ${formatMoney(tax)})`);
    
    await user.save();
    
    const embed = createSuccessEmbed(
        'Para Çekildi',
        `**${formatMoney(amount)}** hesabınızdan çekildi.`
    )
    .addFields(
        { name: '💵 Çekilen', value: formatMoney(amount), inline: true },
        { name: '📊 Vergi (%1)', value: formatMoney(tax), inline: true },
        { name: '💰 Net', value: formatMoney(netAmount), inline: true },
        { name: '🏦 Kalan Bakiye', value: formatMoney(user.balance), inline: false }
    );
    
    return message.reply({ embeds: [embed] });
}

/**
 * Transfer
 */
async function transfer(message, args) {
    const sender = await User.findOne({ odUserId: message.author.id });
    
    if (!sender) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (sender.accountStatus === 'frozen') {
        return message.reply({ embeds: [createErrorEmbed('Hesap Dondurulmuş', 'Hesabınız dondurulmuş durumda. Transfer yapamazsınız.')] });
    }
    
    if (sender.defaulted) {
        return message.reply({ embeds: [createErrorEmbed('Transfer Yasağı', 'Temerrüt durumundasınız. Önce borcunuzu ödeyin.\n`!temerrut-durum` ile durumunuzu kontrol edin.')] });
    }
    
    // Argümanları kontrol et
    if (args.length < 2) {
        return message.reply({ embeds: [createErrorEmbed('Eksik Bilgi', 'Kullanım: `!transfer @kullanıcı miktar`\nÖrnek: `!transfer @Ali 1000`')] });
    }
    
    // Alıcıyı bul
    const targetId = extractUserId(args[0]);
    if (!targetId) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Kullanıcı', 'Lütfen geçerli bir kullanıcı etiketleyin.')] });
    }
    
    if (targetId === message.author.id) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz İşlem', 'Kendinize transfer yapamazsınız.')] });
    }
    
    const receiver = await User.findOne({ odUserId: targetId });
    if (!receiver) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Alıcının banka hesabı bulunmuyor.')] });
    }
    
    if (receiver.accountStatus === 'frozen') {
        return message.reply({ embeds: [createErrorEmbed('Alıcı Hesabı Dondurulmuş', 'Alıcının hesabı dondurulmuş durumda.')] });
    }
    
    // Miktar
    const amount = parseAmount(args[1], sender.balance);
    if (!amount || amount < config.transfer.minAmount) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Miktar', `Minimum transfer miktarı: ${formatMoney(config.transfer.minAmount)}`)] });
    }
    
    // Limit kontrolü
    sender.checkAndResetLimits();
    const transferLimit = sender.getTransferLimit(config);
    
    if (sender.dailyTransfers + amount > transferLimit) {
        return message.reply({ embeds: [createErrorEmbed('Günlük Limit Aşıldı', `Günlük transfer limitiniz: ${formatMoney(transferLimit)}\nKullanılan: ${formatMoney(sender.dailyTransfers)}\nKalan: ${formatMoney(transferLimit - sender.dailyTransfers)}`)] });
    }
    
    if (sender.hourlyTransfers + amount > config.transfer.hourlyLimit) {
        return message.reply({ embeds: [createErrorEmbed('Saatlik Limit Aşıldı', `Saatlik transfer limitiniz: ${formatMoney(config.transfer.hourlyLimit)}\nKullanılan: ${formatMoney(sender.hourlyTransfers)}`)] });
    }
    
    // Bakiye kontrolü
    const tax = Math.floor(amount * config.transfer.taxRate);
    const totalCost = amount + tax;
    
    if (sender.balance < totalCost) {
        return message.reply({ embeds: [createErrorEmbed('Yetersiz Bakiye', `Transfer tutarı: ${formatMoney(amount)}\nVergi (%2): ${formatMoney(tax)}\nToplam: ${formatMoney(totalCost)}\nBakiyeniz: ${formatMoney(sender.balance)}`)] });
    }
    
    // Transfer işlemi
    sender.balance -= totalCost;
    sender.dailyTransfers += amount;
    sender.hourlyTransfers += amount;
    sender.stats.totalTransferred += amount;
    sender.addTransaction('transfer_out', amount, `${receiver.username}'e transfer (Vergi: ${formatMoney(tax)})`, receiver.odUserId);
    
    receiver.balance += amount;
    receiver.stats.totalReceived += amount;
    receiver.addTransaction('transfer_in', amount, `${sender.username}'den transfer`, sender.odUserId);
    
    // XP kazanımı
    await sender.addXP(config.transfer.xpGain, config);
    
    await sender.save();
    await receiver.save();
    
    const embed = new EmbedBuilder()
        .setColor(config.colors.success)
        .setTitle('✅ Transfer Başarılı')
        .setDescription(`**${receiver.username}** kullanıcısına başarıyla para transferi yapıldı.`)
        .addFields(
            { name: '💸 Transfer Tutarı', value: formatMoney(amount), inline: true },
            { name: '📊 Vergi (%2)', value: formatMoney(tax), inline: true },
            { name: '💰 Toplam Kesinti', value: formatMoney(totalCost), inline: true },
            { name: '🏦 Kalan Bakiyeniz', value: formatMoney(sender.balance), inline: true },
            { name: '📥 Alıcı Bakiyesi', value: formatMoney(receiver.balance), inline: true },
            { name: '✨ Kazanılan XP', value: `+${config.transfer.xpGain}`, inline: true }
        )
        .setFooter({ text: `IBAN: ${formatIBAN(receiver.iban)}` })
        .setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * IBAN ile Transfer
 */
async function ibanTransfer(message, args) {
    const sender = await User.findOne({ odUserId: message.author.id });
    
    if (!sender) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (sender.accountStatus === 'frozen' || sender.defaulted) {
        return message.reply({ embeds: [createErrorEmbed('İşlem Engellenmiş', 'Hesabınız dondurulmuş veya temerrüt durumundasınız.')] });
    }
    
    if (args.length < 2) {
        return message.reply({ embeds: [createErrorEmbed('Eksik Bilgi', 'Kullanım: `!iban-transfer IBAN miktar`\nÖrnek: `!iban-transfer TR123456789012345678901234 1000`')] });
    }
    
    const iban = args[0].replace(/\s/g, '').toUpperCase();
    const amount = parseAmount(args[1], sender.balance);
    
    // IBAN doğrulama
    if (!/^TR\d{24}$/.test(iban)) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz IBAN', 'Lütfen geçerli bir TR IBAN girin.')] });
    }
    
    const receiver = await User.findOne({ iban: iban });
    if (!receiver) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Bu IBAN\'a ait hesap bulunamadı.')] });
    }
    
    if (receiver.odUserId === sender.odUserId) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz İşlem', 'Kendinize transfer yapamazsınız.')] });
    }
    
    // Miktar ve limit kontrolleri (transfer fonksiyonundakiyle aynı)
    if (!amount || amount < config.transfer.minAmount) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Miktar', `Minimum transfer: ${formatMoney(config.transfer.minAmount)}`)] });
    }
    
    sender.checkAndResetLimits();
    const transferLimit = sender.getTransferLimit(config);
    
    if (sender.dailyTransfers + amount > transferLimit) {
        return message.reply({ embeds: [createErrorEmbed('Limit Aşıldı', `Günlük limitiniz: ${formatMoney(transferLimit)}`)] });
    }
    
    const tax = Math.floor(amount * config.transfer.taxRate);
    const totalCost = amount + tax;
    
    if (sender.balance < totalCost) {
        return message.reply({ embeds: [createErrorEmbed('Yetersiz Bakiye', `Toplam maliyet: ${formatMoney(totalCost)}\nBakiyeniz: ${formatMoney(sender.balance)}`)] });
    }
    
    // Transfer işlemi
    sender.balance -= totalCost;
    sender.dailyTransfers += amount;
    sender.hourlyTransfers += amount;
    sender.stats.totalTransferred += amount;
    sender.addTransaction('transfer_out', amount, `IBAN transferi: ${formatIBAN(iban)}`, receiver.odUserId);
    
    receiver.balance += amount;
    receiver.stats.totalReceived += amount;
    receiver.addTransaction('transfer_in', amount, `IBAN transferi: ${sender.username}`, sender.odUserId);
    
    await sender.addXP(config.transfer.xpGain, config);
    await sender.save();
    await receiver.save();
    
    const embed = createSuccessEmbed(
        'IBAN Transferi Başarılı',
        `**${formatMoney(amount)}** başarıyla gönderildi.`
    )
    .addFields(
        { name: '📧 Alıcı IBAN', value: `\`${formatIBAN(iban)}\``, inline: false },
        { name: '👤 Alıcı', value: receiver.username, inline: true },
        { name: '📊 Vergi', value: formatMoney(tax), inline: true },
        { name: '🏦 Kalan', value: formatMoney(sender.balance), inline: true }
    );
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    yatir,
    cek,
    transfer,
    ibanTransfer,
    // Alias
    gonder: transfer
};
