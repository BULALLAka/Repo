/**
 * ========================================
 * FATURA KOMUTLARI
 * ========================================
 * !faturalar, !fatura-ode
 */

const { EmbedBuilder } = require('discord.js');
const User = require('../models/User');
const config = require('../config/config');
const {
    formatMoney,
    formatDate,
    createSuccessEmbed,
    createErrorEmbed,
    createBankEmbed
} = require('../utils/helpers');

/**
 * Faturaları Listele
 */
async function faturalar(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    // Aktif faturaları getir
    const unpaidBills = user.bills.filter(b => !b.paid);
    const paidBills = user.bills.filter(b => b.paid).slice(-5); // Son 5 ödenen
    
    const embed = createBankEmbed('Faturalarınız');
    
    if (unpaidBills.length === 0) {
        embed.setDescription('✅ Ödenmemiş faturanız bulunmuyor!');
    } else {
        let totalUnpaid = 0;
        let billsList = '';
        
        unpaidBills.forEach((bill, index) => {
            const billInfo = config.bills.types[bill.type] || { name: bill.type };
            const isOverdue = new Date() > bill.dueDate;
            const status = isOverdue ? '🔴 GECİKMİŞ' : '🟡 Bekliyor';
            
            billsList += `**${index + 1}.** ${billInfo.name}\n`;
            billsList += `   💰 ${formatMoney(bill.amount)} | 📅 ${formatDate(bill.dueDate)} | ${status}\n\n`;
            totalUnpaid += bill.amount;
        });
        
        embed.setDescription(`**${unpaidBills.length}** ödenmemiş faturanız var.`);
        embed.addFields(
            { name: '📄 Ödenmemiş Faturalar', value: billsList, inline: false },
            { name: '💰 Toplam Borç', value: formatMoney(totalUnpaid), inline: true },
            { name: '🏦 Bakiyeniz', value: formatMoney(user.balance), inline: true }
        );
    }
    
    // Son ödenen faturalar
    if (paidBills.length > 0) {
        let paidList = paidBills.map(bill => {
            const billInfo = config.bills.types[bill.type] || { name: bill.type };
            return `✅ ${billInfo.name} - ${formatMoney(bill.amount)}`;
        }).join('\n');
        
        embed.addFields({ name: '📋 Son Ödenen Faturalar', value: paidList, inline: false });
    }
    
    embed.addFields({
        name: '💡 Fatura Ödeme',
        value: '`!fatura-ode <numara>` veya `!fatura-ode all`',
        inline: false
    });
    
    embed.setFooter({ text: '⚠️ Gecikmeli faturalar kredi notunuzu düşürür!' });
    
    return message.reply({ embeds: [embed] });
}

/**
 * Fatura Öde
 */
async function faturaOde(message, args) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (user.accountStatus === 'frozen') {
        return message.reply({ embeds: [createErrorEmbed('Hesap Dondurulmuş', 'Hesabınız dondurulmuş durumda.')] });
    }
    
    const unpaidBills = user.bills.filter(b => !b.paid);
    
    if (unpaidBills.length === 0) {
        return message.reply({ embeds: [createSuccessEmbed('Fatura Yok', 'Ödenmemiş faturanız bulunmuyor.')] });
    }
    
    // Tüm faturaları öde
    if (args[0] === 'all' || args[0] === 'hepsi' || args[0] === 'tümü') {
        const totalAmount = unpaidBills.reduce((sum, b) => sum + b.amount, 0);
        
        if (user.balance < totalAmount) {
            return message.reply({ embeds: [createErrorEmbed('Yetersiz Bakiye', `Toplam fatura: ${formatMoney(totalAmount)}\nBakiyeniz: ${formatMoney(user.balance)}`)] });
        }
        
        // Tüm faturaları öde
        let paidCount = 0;
        for (const bill of user.bills) {
            if (!bill.paid) {
                bill.paid = true;
                bill.paidDate = new Date();
                paidCount++;
                
                // Kredi notu artır
                user.creditScore = Math.min(config.creditScore.max, user.creditScore + config.creditScore.billPaymentBonus);
            }
        }
        
        user.balance -= totalAmount;
        user.stats.billsPaid += paidCount;
        user.addTransaction('bill', totalAmount, `${paidCount} fatura ödendi`);
        
        await user.save();
        
        const embed = createSuccessEmbed(
            'Tüm Faturalar Ödendi!',
            `**${paidCount}** fatura başarıyla ödendi.`
        )
        .addFields(
            { name: '💰 Toplam Ödeme', value: formatMoney(totalAmount), inline: true },
            { name: '📈 Kredi Notu', value: `+${paidCount * config.creditScore.billPaymentBonus}`, inline: true },
            { name: '🏦 Kalan Bakiye', value: formatMoney(user.balance), inline: true }
        );
        
        return message.reply({ embeds: [embed] });
    }
    
    // Tek fatura öde
    const billIndex = parseInt(args[0]) - 1;
    
    if (isNaN(billIndex) || billIndex < 0 || billIndex >= unpaidBills.length) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Numara', `1 ile ${unpaidBills.length} arasında bir numara girin.\nFaturaları görmek için: \`!faturalar\``)] });
    }
    
    const bill = unpaidBills[billIndex];
    
    if (user.balance < bill.amount) {
        return message.reply({ embeds: [createErrorEmbed('Yetersiz Bakiye', `Fatura tutarı: ${formatMoney(bill.amount)}\nBakiyeniz: ${formatMoney(user.balance)}`)] });
    }
    
    // Faturayı öde
    const realBill = user.bills.find(b => 
        !b.paid && 
        b.type === bill.type && 
        b.amount === bill.amount
    );
    
    if (realBill) {
        realBill.paid = true;
        realBill.paidDate = new Date();
    }
    
    user.balance -= bill.amount;
    user.creditScore = Math.min(config.creditScore.max, user.creditScore + config.creditScore.billPaymentBonus);
    user.stats.billsPaid += 1;
    user.addTransaction('bill', bill.amount, `${config.bills.types[bill.type]?.name || bill.type} ödendi`);
    
    await user.save();
    
    const embed = createSuccessEmbed(
        'Fatura Ödendi!',
        `**${config.bills.types[bill.type]?.name || bill.type}** başarıyla ödendi.`
    )
    .addFields(
        { name: '💰 Ödenen Tutar', value: formatMoney(bill.amount), inline: true },
        { name: '📈 Kredi Notu', value: `+${config.creditScore.billPaymentBonus}`, inline: true },
        { name: '🏦 Kalan Bakiye', value: formatMoney(user.balance), inline: true }
    );
    
    return message.reply({ embeds: [embed] });
}

/**
 * Fatura Türleri
 */
async function faturaTurleri(message) {
    const embed = createBankEmbed('Fatura Türleri')
        .setDescription('Her ay aşağıdaki faturalar otomatik olarak oluşturulur:');
    
    for (const [type, data] of Object.entries(config.bills.types)) {
        embed.addFields({
            name: `📄 ${data.name}`,
            value: `💰 ${formatMoney(data.amount)}/ay`,
            inline: true
        });
    }
    
    const totalMonthly = Object.values(config.bills.types).reduce((sum, b) => sum + b.amount, 0);
    
    embed.addFields(
        { name: '\u200b', value: '───────────────────', inline: false },
        { name: '💰 Aylık Toplam', value: formatMoney(totalMonthly), inline: true },
        { name: '📅 Fatura Günü', value: `Her ayın ${config.bills.generationDay}\'i`, inline: true },
        { name: '⚠️ Gecikme Cezası', value: `Kredi notu -${config.bills.unpaidPenalty}`, inline: true }
    );
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    faturalar,
    faturaOde,
    faturaTurleri
};
