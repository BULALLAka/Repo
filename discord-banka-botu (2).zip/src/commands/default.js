/**
 * ========================================
 * TEMERRÜT KOMUTLARI
 * ========================================
 * !temerrut, !temerrut-durum, !borc-yapilandir, !taksit-ode
 */

const { EmbedBuilder } = require('discord.js');
const User = require('../models/User');
const config = require('../config/config');
const {
    formatMoney,
    formatPercent,
    formatDate,
    formatDuration,
    parseAmount,
    createSuccessEmbed,
    createErrorEmbed,
    createWarningEmbed,
    createBankEmbed
} = require('../utils/helpers');

/**
 * Temerrüt Bilgisi
 */
async function temerrut(message) {
    const embed = createBankEmbed('Temerrüt Sistemi Bilgisi')
        .setDescription('Kredi borcunuzu zamanında ödemezseniz temerrüt durumuna düşersiniz.')
        .addFields(
            { name: '⏰ Temerrüt Başlangıcı', value: 'Son ödeme tarihinden 24 saat sonra', inline: false },
            { name: '💰 Gecikme Cezası', value: `İlk gün: ${formatPercent(config.default.lateFee)} eklenir`, inline: true },
            { name: '📈 Günlük Faiz', value: `Her gün: ${formatPercent(config.default.dailyInterest)}`, inline: true },
            { name: '💵 Maaş Kesintisi', value: `${formatPercent(config.default.salaryDeduction)} borca aktarılır`, inline: true },
            { name: '🚫 Transfer Yasağı', value: 'Transfer yapamazsınız', inline: true },
            { name: '📉 Kredi Notu', value: `Günlük -${config.creditScore.latePenalty} puan`, inline: true },
            { name: '\u200b', value: '\u200b', inline: true }
        )
        .addFields(
            { name: '⚠️ Ağır Temerrüt', value: `${config.default.severeDefaultDays} gün sonra`, inline: true },
            { name: '🔒 Hesap Dondurma', value: `${config.default.freezeAccountDays} gün sonra`, inline: true },
            { name: '📋 Yapılandırma', value: '`!borc-yapilandir` ile taksit yapın', inline: true }
        )
        .setFooter({ text: 'Borcunuzu zamanında ödeyin, temerrütten kaçının!' });
    
    return message.reply({ embeds: [embed] });
}

/**
 * Temerrüt Durumu
 */
async function temerrütDurum(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (!user.defaulted && user.creditDebt <= 0) {
        const embed = createSuccessEmbed(
            'Temerrüt Durumu',
            '✅ Temerrütte değilsiniz ve kredi borcunuz bulunmuyor.'
        )
        .addFields({ name: '📊 Kredi Notunuz', value: user.creditScore.toString(), inline: true });
        return message.reply({ embeds: [embed] });
    }
    
    if (!user.defaulted && user.creditDebt > 0) {
        const now = new Date();
        const daysUntilDefault = user.creditDueDate 
            ? Math.ceil((user.creditDueDate - now) / (1000 * 60 * 60 * 24))
            : 'Belirsiz';
        
        const embed = createWarningEmbed(
            'Kredi Borcu Mevcut',
            'Henüz temerrütte değilsiniz ama kredi borcunuz var.'
        )
        .addFields(
            { name: '💳 Borç', value: formatMoney(user.creditDebt), inline: true },
            { name: '📅 Son Ödeme', value: formatDate(user.creditDueDate), inline: true },
            { name: '⏰ Kalan Süre', value: `${daysUntilDefault} gün`, inline: true }
        )
        .setFooter({ text: 'Zamanında ödeme yaparak temerrütten kaçının!' });
        
        return message.reply({ embeds: [embed] });
    }
    
    // Temerrüt durumunda
    const defaultDays = user.calculateDefaultDays();
    const isSevere = defaultDays >= config.default.severeDefaultDays;
    const willFreeze = defaultDays >= config.default.freezeAccountDays;
    
    const embed = new EmbedBuilder()
        .setColor(config.colors.error)
        .setTitle('🚨 TEMERRÜT DURUMUNUZ')
        .setDescription(`**${defaultDays} gündür** temerrüt durumundasınız!`)
        .addFields(
            { name: '💳 Toplam Borç', value: formatMoney(user.creditDebt), inline: true },
            { name: '📅 Temerrüt Başlangıcı', value: formatDate(user.defaultStartDate), inline: true },
            { name: '📈 Günlük Faiz', value: formatPercent(config.default.dailyInterest), inline: true }
        );
    
    // Durum seviyesi
    if (willFreeze || user.accountStatus === 'frozen') {
        embed.addFields({
            name: '🔒 HESAP DONDURULDU',
            value: 'Hesabınız temerrüt nedeniyle donduruldu.\nBorcunuzu ödeyin veya yapılandırın.',
            inline: false
        });
    } else if (isSevere) {
        embed.addFields({
            name: '⚠️ AĞIR TEMERRÜT',
            value: `${config.default.freezeAccountDays - defaultDays} gün içinde hesabınız dondurulacak!`,
            inline: false
        });
    } else {
        embed.addFields({
            name: '⏰ Uyarı',
            value: `${config.default.severeDefaultDays - defaultDays} gün içinde ağır temerrüte düşeceksiniz.`,
            inline: false
        });
    }
    
    // Kısıtlamalar
    embed.addFields({
        name: '🚫 Aktif Kısıtlamalar',
        value: 
            '• Transfer yapamazsınız\n' +
            '• Yeni kredi çekemezsiniz\n' +
            `• Maaşınızdan %${config.default.salaryDeduction * 100} kesilir\n` +
            '• Kredi notunuz düşüyor',
        inline: false
    });
    
    embed.addFields({
        name: '💡 Ne Yapabilirsiniz?',
        value: 
            '• `!kredi-ode <miktar>` - Borcunuzu ödeyin\n' +
            '• `!borc-yapilandir` - Taksitlendirin',
        inline: false
    });
    
    embed.setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Borç Yapılandır
 */
async function borcYapilandir(message, args) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (user.restructure && user.restructure.status === 'active') {
        return message.reply({ embeds: [createErrorEmbed('Zaten Yapılandırılmış', 'Aktif bir yapılandırmanız var. `!yapilandirma-durum` ile görüntüleyin.')] });
    }
    
    if (user.creditDebt < config.restructure.minDebt) {
        return message.reply({ embeds: [createErrorEmbed('Yetersiz Borç', `Yapılandırma için minimum ${formatMoney(config.restructure.minDebt)} borç gerekiyor.\nMevcut borç: ${formatMoney(user.creditDebt)}`)] });
    }
    
    // Taksit seçeneklerini göster
    if (!args[0]) {
        const reducedInterest = user.creditDebt * (1 - config.restructure.interestReduction);
        
        const embed = createBankEmbed('Borç Yapılandırma')
            .setDescription('Borcunuzu taksitlendirerek ödeyin.')
            .addFields(
                { name: '💳 Mevcut Borç', value: formatMoney(user.creditDebt), inline: true },
                { name: '📉 İndirimli Borç', value: formatMoney(reducedInterest), inline: true },
                { name: '✨ Faiz İndirimi', value: formatPercent(config.restructure.interestReduction), inline: true }
            );
        
        for (const installment of config.restructure.installments) {
            const monthlyPayment = Math.ceil(reducedInterest / installment);
            embed.addFields({
                name: `📅 ${installment} Taksit`,
                value: `Aylık: ${formatMoney(monthlyPayment)}\n\`!borc-yapilandir ${installment}\``,
                inline: true
            });
        }
        
        embed.addFields({
            name: '📋 Avantajlar',
            value: 
                `• ${formatPercent(config.restructure.interestReduction)} faiz indirimi\n` +
                `• Temerrüt kaldırılır\n` +
                `• Her taksit ödemesinde kredi notu +${config.restructure.creditScoreRecovery}`,
            inline: false
        })
        .setFooter({ text: 'Yapılandırma bir kez yapılabilir. Dikkatli seçin!' });
        
        return message.reply({ embeds: [embed] });
    }
    
    const installments = parseInt(args[0]);
    
    if (!config.restructure.installments.includes(installments)) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Taksit', `Taksit seçenekleri: ${config.restructure.installments.join(', ')}`)] });
    }
    
    // Yapılandırma oluştur
    const reducedDebt = Math.floor(user.creditDebt * (1 - config.restructure.interestReduction));
    const installmentAmount = Math.ceil(reducedDebt / installments);
    const nextPayment = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 gün sonra
    
    user.restructure = {
        originalDebt: user.creditDebt,
        totalAmount: reducedDebt,
        installmentAmount: installmentAmount,
        installments: installments,
        paidInstallments: 0,
        nextPaymentDate: nextPayment,
        startDate: new Date(),
        status: 'active'
    };
    
    // Temerrüt durumunu kaldır
    user.defaulted = false;
    user.defaultStartDate = null;
    user.defaultDays = 0;
    user.creditDebt = 0;
    user.creditDueDate = null;
    
    // Hesap donmuşsa aç
    if (user.accountStatus === 'frozen') {
        user.accountStatus = 'active';
    }
    
    user.addTransaction('credit_payment', 0, `Borç yapılandırıldı: ${installments} taksit`);
    
    await user.save();
    
    const embed = createSuccessEmbed(
        'Borç Yapılandırıldı!',
        'Borcunuz başarıyla yapılandırıldı.'
    )
    .addFields(
        { name: '💳 Orijinal Borç', value: formatMoney(user.restructure.originalDebt), inline: true },
        { name: '📉 Yeni Borç', value: formatMoney(reducedDebt), inline: true },
        { name: '✨ Tasarruf', value: formatMoney(user.restructure.originalDebt - reducedDebt), inline: true },
        { name: '📅 Taksit Sayısı', value: `${installments} ay`, inline: true },
        { name: '💰 Aylık Taksit', value: formatMoney(installmentAmount), inline: true },
        { name: '📆 İlk Ödeme', value: formatDate(nextPayment), inline: true }
    )
    .setFooter({ text: 'Her ay taksitinizi ödemeyi unutmayın: !taksit-ode' });
    
    return message.reply({ embeds: [embed] });
}

/**
 * Taksit Öde
 */
async function taksitOde(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (!user.restructure || user.restructure.status !== 'active') {
        return message.reply({ embeds: [createErrorEmbed('Yapılandırma Yok', 'Aktif bir borç yapılandırmanız bulunmuyor.')] });
    }
    
    const r = user.restructure;
    const remainingInstallments = r.installments - r.paidInstallments;
    
    if (remainingInstallments <= 0) {
        r.status = 'completed';
        await user.save();
        return message.reply({ embeds: [createSuccessEmbed('Borç Bitti', 'Tüm taksitlerinizi ödediniz!')] });
    }
    
    if (user.balance < r.installmentAmount) {
        return message.reply({ embeds: [createErrorEmbed('Yetersiz Bakiye', `Taksit tutarı: ${formatMoney(r.installmentAmount)}\nBakiyeniz: ${formatMoney(user.balance)}`)] });
    }
    
    // Taksit öde
    user.balance -= r.installmentAmount;
    r.paidInstallments += 1;
    r.nextPaymentDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    
    // Kredi notunu artır
    user.creditScore = Math.min(config.creditScore.max, user.creditScore + config.restructure.creditScoreRecovery);
    
    user.stats.creditsRepaid += r.installmentAmount;
    user.addTransaction('credit_payment', r.installmentAmount, `Taksit ödemesi (${r.paidInstallments}/${r.installments})`);
    
    // Son taksit mi?
    if (r.paidInstallments >= r.installments) {
        r.status = 'completed';
    }
    
    await user.save();
    
    const isComplete = r.status === 'completed';
    
    const embed = new EmbedBuilder()
        .setColor(isComplete ? config.colors.success : config.colors.info)
        .setTitle(isComplete ? '🎉 Tüm Taksitler Ödendi!' : '✅ Taksit Ödendi')
        .addFields(
            { name: '💰 Ödenen', value: formatMoney(r.installmentAmount), inline: true },
            { name: '📊 İlerleme', value: `${r.paidInstallments}/${r.installments}`, inline: true },
            { name: '📈 Kredi Notu', value: `+${config.restructure.creditScoreRecovery} (${user.creditScore})`, inline: true },
            { name: '🏦 Bakiye', value: formatMoney(user.balance), inline: true }
        );
    
    if (!isComplete) {
        embed.addFields(
            { name: '📅 Sonraki Taksit', value: formatDate(r.nextPaymentDate), inline: true },
            { name: '💳 Kalan Taksit', value: `${r.installments - r.paidInstallments}`, inline: true }
        );
    } else {
        embed.setDescription('🎊 Tebrikler! Borç yapılandırmanızı başarıyla tamamladınız!');
    }
    
    embed.setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Yapılandırma Durumu
 */
async function yapilandirmaDurum(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (!user.restructure) {
        return message.reply({ embeds: [createErrorEmbed('Yapılandırma Yok', 'Borç yapılandırmanız bulunmuyor.')] });
    }
    
    const r = user.restructure;
    const remainingAmount = (r.installments - r.paidInstallments) * r.installmentAmount;
    const paidAmount = r.paidInstallments * r.installmentAmount;
    const progressPercent = Math.round((r.paidInstallments / r.installments) * 100);
    
    const embed = createBankEmbed('Yapılandırma Durumu')
        .addFields(
            { name: '📊 Durum', value: r.status === 'active' ? '🟢 Aktif' : r.status === 'completed' ? '✅ Tamamlandı' : '🔴 Temerrüt', inline: true },
            { name: '💳 Orijinal Borç', value: formatMoney(r.originalDebt), inline: true },
            { name: '📉 Yapılandırılan', value: formatMoney(r.totalAmount), inline: true },
            { name: '💰 Taksit Tutarı', value: formatMoney(r.installmentAmount), inline: true },
            { name: '📅 Taksit Sayısı', value: `${r.installments}`, inline: true },
            { name: '✅ Ödenen Taksit', value: `${r.paidInstallments}`, inline: true },
            { name: '💵 Ödenen Tutar', value: formatMoney(paidAmount), inline: true },
            { name: '💳 Kalan Tutar', value: formatMoney(remainingAmount), inline: true },
            { name: '📈 İlerleme', value: `${progressPercent}%`, inline: true }
        );
    
    if (r.status === 'active') {
        embed.addFields({ name: '📆 Sonraki Ödeme', value: formatDate(r.nextPaymentDate), inline: false });
    }
    
    embed.setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    temerrut,
    temerrütDurum,
    borcYapilandir,
    taksitOde,
    yapilandirmaDurum
};
