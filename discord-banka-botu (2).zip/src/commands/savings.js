/**
 * ========================================
 * VADELİ HESAP KOMUTLARI
 * ========================================
 * !vadeli-ac, !vadeli-boz, !vadeli-durum
 */

const { EmbedBuilder } = require('discord.js');
const User = require('../models/User');
const config = require('../config/config');
const {
    formatMoney,
    formatPercent,
    formatDate,
    formatDuration,
    parseAmount,
    createSuccessEmbed,
    createErrorEmbed,
    createBankEmbed
} = require('../utils/helpers');

/**
 * Vadeli Hesap Aç
 */
async function vadeliAc(message, args) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (user.accountStatus === 'frozen') {
        return message.reply({ embeds: [createErrorEmbed('Hesap Dondurulmuş', 'Hesabınız dondurulmuş durumda.')] });
    }
    
    if (args.length < 2) {
        const embed = createBankEmbed('Vadeli Hesap Açma')
            .setDescription('Vadeli hesap açarak paranıza faiz kazandırabilirsiniz.')
            .addFields(
                { name: '📋 Kullanım', value: '`!vadeli-ac <miktar> <gün>`', inline: false },
                { name: '📅 Vade Seçenekleri', value: 
                    `• **7 gün** - ${formatPercent(config.savings.periods[7].rate)} faiz\n` +
                    `• **14 gün** - ${formatPercent(config.savings.periods[14].rate)} faiz\n` +
                    `• **30 gün** - ${formatPercent(config.savings.periods[30].rate)} faiz`,
                    inline: false
                },
                { name: '💰 Minimum Miktar', value: formatMoney(config.savings.minAmount), inline: true },
                { name: '⚠️ Erken Bozma Cezası', value: formatPercent(config.savings.earlyBreakPenalty), inline: true }
            )
            .addFields({ name: '📝 Örnek', value: '`!vadeli-ac 10000 30`', inline: false });
        return message.reply({ embeds: [embed] });
    }
    
    const amount = parseAmount(args[0], user.balance);
    const period = parseInt(args[1]);
    
    if (!amount || amount < config.savings.minAmount) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Miktar', `Minimum yatırım: ${formatMoney(config.savings.minAmount)}`)] });
    }
    
    if (![7, 14, 30].includes(period)) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Vade', 'Vade seçenekleri: 7, 14 veya 30 gün')] });
    }
    
    if (amount > user.balance) {
        return message.reply({ embeds: [createErrorEmbed('Yetersiz Bakiye', `Bakiyeniz: ${formatMoney(user.balance)}`)] });
    }
    
    // Aktif vadeli hesap sayısı kontrolü (max 5)
    const activeAccounts = user.savingsAccounts.filter(acc => acc.status === 'active');
    if (activeAccounts.length >= 5) {
        return message.reply({ embeds: [createErrorEmbed('Limit Aşıldı', 'En fazla 5 aktif vadeli hesabınız olabilir.')] });
    }
    
    const periodData = config.savings.periods[period];
    const endDate = new Date(Date.now() + period * 24 * 60 * 60 * 1000);
    const expectedReturn = Math.floor(amount * (1 + periodData.rate));
    const profit = expectedReturn - amount;
    
    // Vadeli hesap oluştur
    user.savingsAccounts.push({
        amount: amount,
        period: period,
        interestRate: periodData.rate,
        startDate: new Date(),
        endDate: endDate,
        status: 'active'
    });
    
    user.balance -= amount;
    user.addTransaction('savings_deposit', amount, `Vadeli hesap açıldı (${period} gün, ${formatPercent(periodData.rate)})`);
    
    await user.save();
    
    const embed = new EmbedBuilder()
        .setColor(config.colors.success)
        .setTitle('💎 Vadeli Hesap Açıldı!')
        .setDescription('Paranız vadeli hesaba aktarıldı.')
        .addFields(
            { name: '💰 Yatırılan Miktar', value: formatMoney(amount), inline: true },
            { name: '📅 Vade Süresi', value: `${period} gün`, inline: true },
            { name: '📈 Faiz Oranı', value: formatPercent(periodData.rate), inline: true },
            { name: '💵 Beklenen Getiri', value: formatMoney(expectedReturn), inline: true },
            { name: '✨ Kar', value: formatMoney(profit), inline: true },
            { name: '📆 Vade Bitişi', value: formatDate(endDate), inline: true },
            { name: '🏦 Kalan Bakiye', value: formatMoney(user.balance), inline: false }
        )
        .setFooter({ text: '⚠️ Erken bozma durumunda %5 ceza uygulanır' })
        .setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Vadeli Hesap Durumu
 */
async function vadeliDurum(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    const activeAccounts = user.savingsAccounts.filter(acc => acc.status === 'active');
    
    if (activeAccounts.length === 0) {
        const embed = createBankEmbed('Vadeli Hesaplar')
            .setDescription('Aktif vadeli hesabınız bulunmuyor.\n\nVadeli hesap açmak için: `!vadeli-ac <miktar> <gün>`');
        return message.reply({ embeds: [embed] });
    }
    
    const embed = createBankEmbed('Vadeli Hesaplarınız')
        .setDescription(`Toplam **${activeAccounts.length}** aktif vadeli hesabınız var.`);
    
    let totalSavings = 0;
    let totalExpected = 0;
    
    activeAccounts.forEach((acc, index) => {
        const now = new Date();
        const remaining = acc.endDate - now;
        const isMatured = remaining <= 0;
        const expectedReturn = Math.floor(acc.amount * (1 + acc.interestRate));
        
        totalSavings += acc.amount;
        totalExpected += expectedReturn;
        
        const status = isMatured ? '✅ Vadesi Doldu' : `⏰ ${formatDuration(remaining)}`;
        
        embed.addFields({
            name: `#${index + 1} - ${config.savings.periods[acc.period].name}`,
            value: 
                `💰 Miktar: ${formatMoney(acc.amount)}\n` +
                `📈 Faiz: ${formatPercent(acc.interestRate)}\n` +
                `💵 Beklenen: ${formatMoney(expectedReturn)}\n` +
                `📅 Durum: ${status}`,
            inline: true
        });
    });
    
    embed.addFields(
        { name: '\u200b', value: '───────────────────', inline: false },
        { name: '📊 Toplam Vadeli', value: formatMoney(totalSavings), inline: true },
        { name: '💵 Beklenen Toplam', value: formatMoney(totalExpected), inline: true },
        { name: '✨ Toplam Kar', value: formatMoney(totalExpected - totalSavings), inline: true }
    );
    
    embed.setFooter({ text: 'Vadeli hesap bozmak için: !vadeli-boz <numara>' });
    
    return message.reply({ embeds: [embed] });
}

/**
 * Vadeli Hesap Boz
 */
async function vadeliBoz(message, args) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    const activeAccounts = user.savingsAccounts.filter(acc => acc.status === 'active');
    
    if (activeAccounts.length === 0) {
        return message.reply({ embeds: [createErrorEmbed('Vadeli Hesap Yok', 'Aktif vadeli hesabınız bulunmuyor.')] });
    }
    
    const accountIndex = parseInt(args[0]) - 1;
    
    if (isNaN(accountIndex) || accountIndex < 0 || accountIndex >= activeAccounts.length) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Numara', `1 ile ${activeAccounts.length} arasında bir numara girin.\nHesaplarınızı görmek için: \`!vadeli-durum\``)] });
    }
    
    const account = activeAccounts[accountIndex];
    const now = new Date();
    const isMatured = account.endDate <= now;
    
    let returnAmount;
    let penalty = 0;
    let profit = 0;
    
    if (isMatured) {
        // Vade dolmuş - faiz ile birlikte ver
        returnAmount = Math.floor(account.amount * (1 + account.interestRate));
        profit = returnAmount - account.amount;
    } else {
        // Erken bozma - ceza uygula
        penalty = Math.floor(account.amount * config.savings.earlyBreakPenalty);
        returnAmount = account.amount - penalty;
    }
    
    // Hesabı kapat
    const realAccount = user.savingsAccounts.find(
        acc => acc.status === 'active' && 
        acc.startDate.getTime() === account.startDate.getTime() &&
        acc.amount === account.amount
    );
    
    if (realAccount) {
        realAccount.status = isMatured ? 'completed' : 'broken';
    }
    
    user.balance += returnAmount;
    user.addTransaction('savings_withdraw', returnAmount, 
        isMatured ? `Vadeli hesap tamamlandı (Kar: ${formatMoney(profit)})` : `Vadeli hesap erken bozuldu (Ceza: ${formatMoney(penalty)})`
    );
    
    await user.save();
    
    const embed = new EmbedBuilder()
        .setColor(isMatured ? config.colors.success : config.colors.warning)
        .setTitle(isMatured ? '✅ Vadeli Hesap Tamamlandı!' : '⚠️ Vadeli Hesap Erken Bozuldu')
        .addFields(
            { name: '💰 Ana Para', value: formatMoney(account.amount), inline: true },
            { name: '📅 Vade', value: `${account.period} gün`, inline: true },
            { name: '📈 Faiz Oranı', value: formatPercent(account.interestRate), inline: true }
        );
    
    if (isMatured) {
        embed.addFields(
            { name: '✨ Kazanılan Faiz', value: formatMoney(profit), inline: true },
            { name: '💵 Toplam İade', value: formatMoney(returnAmount), inline: true }
        );
    } else {
        embed.addFields(
            { name: '❌ Erken Bozma Cezası', value: formatMoney(penalty), inline: true },
            { name: '💵 İade Edilen', value: formatMoney(returnAmount), inline: true }
        );
    }
    
    embed.addFields({ name: '🏦 Yeni Bakiye', value: formatMoney(user.balance), inline: false });
    embed.setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Vadeli Hesap Faiz Oranları
 */
async function faizOranlari(message) {
    const embed = createBankEmbed('Vadeli Hesap Faiz Oranları')
        .setDescription('Paranızı vadeli hesapta tutarak faiz kazanabilirsiniz.')
        .addFields(
            { name: '📅 7 Günlük Vade', value: `Faiz: **${formatPercent(config.savings.periods[7].rate)}**\n1000 TL → ${formatMoney(1000 * (1 + config.savings.periods[7].rate))}`, inline: true },
            { name: '📅 14 Günlük Vade', value: `Faiz: **${formatPercent(config.savings.periods[14].rate)}**\n1000 TL → ${formatMoney(1000 * (1 + config.savings.periods[14].rate))}`, inline: true },
            { name: '📅 30 Günlük Vade', value: `Faiz: **${formatPercent(config.savings.periods[30].rate)}**\n1000 TL → ${formatMoney(1000 * (1 + config.savings.periods[30].rate))}`, inline: true },
            { name: '⚠️ Erken Bozma Cezası', value: formatPercent(config.savings.earlyBreakPenalty), inline: true },
            { name: '💰 Minimum Yatırım', value: formatMoney(config.savings.minAmount), inline: true },
            { name: '📊 Maksimum Hesap', value: '5 adet', inline: true }
        )
        .setFooter({ text: 'Vadeli hesap açmak için: !vadeli-ac <miktar> <gün>' });
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    vadeliAc,
    vadeliDurum,
    vadeliBoz,
    faizOranlari
};
