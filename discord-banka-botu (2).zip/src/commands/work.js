/**
 * ========================================
 * ÇALIŞMA VE MESLEK KOMUTLARI
 * ========================================
 * !calis, !meslek-sec, !meslekler, !maas-al
 */

const { EmbedBuilder } = require('discord.js');
const User = require('../models/User');
const config = require('../config/config');
const {
    formatMoney,
    formatDuration,
    getRemainingTime,
    isOnCooldown,
    getJobEmoji,
    createSuccessEmbed,
    createErrorEmbed,
    createBankEmbed,
    randomInt
} = require('../utils/helpers');

/**
 * Çalış
 */
async function calis(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (user.accountStatus === 'frozen') {
        return message.reply({ embeds: [createErrorEmbed('Hesap Dondurulmuş', 'Hesabınız dondurulmuş durumda.')] });
    }
    
    // Cooldown kontrolü
    if (isOnCooldown(user.lastWork, config.work.cooldown)) {
        const remaining = getRemainingTime(user.lastWork, config.work.cooldown);
        return message.reply({ embeds: [createErrorEmbed('Dinlenme Zamanı', `Tekrar çalışabilmek için **${formatDuration(remaining)}** beklemeniz gerekiyor.`)] });
    }
    
    // Günlük kazanç limiti kontrolü
    user.checkAndResetLimits();
    
    // Kazanç hesaplama (mesleğe göre bonus)
    const jobMultipliers = {
        'işsiz': 0.5,
        'memur': 1.0,
        'esnaf': 1.2,
        'freelancer': 1.4,
        'yazılımcı': 1.6,
        'bankacı': 1.8,
        'yönetici': 2.0
    };
    
    const multiplier = jobMultipliers[user.job] || 1.0;
    const baseEarning = randomInt(config.work.baseEarning, config.work.maxEarning);
    let earning = Math.floor(baseEarning * multiplier);
    
    // Günlük limit kontrolü
    if (user.dailyEarnings + earning > config.security.dailyEarningLimit) {
        earning = config.security.dailyEarningLimit - user.dailyEarnings;
        if (earning <= 0) {
            return message.reply({ embeds: [createErrorEmbed('Günlük Limit', `Günlük kazanç limitinize ulaştınız: ${formatMoney(config.security.dailyEarningLimit)}`)] });
        }
    }
    
    // Gelir vergisi
    const tax = Math.floor(earning * config.taxes.income);
    const netEarning = earning - tax;
    
    // Güncelle
    user.balance += netEarning;
    user.dailyEarnings += earning;
    user.lastWork = new Date();
    user.stats.totalEarned += netEarning;
    user.stats.workCount += 1;
    user.addTransaction('work', netEarning, `Çalışma geliri (Vergi: ${formatMoney(tax)})`);
    
    // XP kazanımı
    const xpResult = await user.addXP(config.work.xpGain, config);
    
    await user.save();
    
    // Çalışma mesajları (mesleğe göre)
    const workMessages = {
        'işsiz': ['Günlük işler yaptınız', 'Sokakta el işleri sattınız', 'Yardım işleri yaptınız'],
        'memur': ['Evrakları tamamladınız', 'Toplantılara katıldınız', 'Raporları hazırladınız'],
        'esnaf': ['Dükkanı işlettiniz', 'Müşterilere hizmet verdiniz', 'Satışları artırdınız'],
        'freelancer': ['Projeyi teslim ettiniz', 'Müşteriyle görüştünüz', 'Yeni iş aldınız'],
        'yazılımcı': ['Kod yazdınız', 'Bug düzelttiniz', 'Yeni özellik geliştirdiniz'],
        'bankacı': ['Kredi dosyalarını incelidiniz', 'Müşteri görüşmesi yaptınız', 'Hesap işlemlerini tamamladınız'],
        'yönetici': ['Toplantı yönettiniz', 'Strateji belirlediniz', 'Takımı koordine ettiniz']
    };
    
    const messages = workMessages[user.job] || workMessages['işsiz'];
    const randomMessage = messages[Math.floor(Math.random() * messages.length)];
    
    const embed = new EmbedBuilder()
        .setColor(config.colors.success)
        .setTitle(`${getJobEmoji(user.job)} Çalışma Tamamlandı!`)
        .setDescription(`**${randomMessage}** ve para kazandınız!`)
        .addFields(
            { name: '💵 Brüt Kazanç', value: formatMoney(earning), inline: true },
            { name: '📊 Vergi (%10)', value: formatMoney(tax), inline: true },
            { name: '💰 Net Kazanç', value: formatMoney(netEarning), inline: true },
            { name: '🏦 Yeni Bakiye', value: formatMoney(user.balance), inline: true },
            { name: '✨ Kazanılan XP', value: `+${config.work.xpGain}`, inline: true },
            { name: '⏰ Sonraki Çalışma', value: formatDuration(config.work.cooldown), inline: true }
        )
        .setFooter({ text: `Meslek: ${user.job} • Çarpan: x${multiplier}` })
        .setTimestamp();
    
    if (xpResult.leveledUp) {
        embed.addFields({ name: '🎉 SEVİYE ATLADIN!', value: `Yeni seviyen: **${xpResult.newLevel}**`, inline: false });
    }
    
    return message.reply({ embeds: [embed] });
}

/**
 * Meslekleri Listele
 */
async function meslekler(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    const embed = createBankEmbed('Meslekler')
        .setDescription('Aşağıdaki mesleklerden birini seçebilirsiniz.\nMeslek seçmek için: `!meslek-sec <meslek>`');
    
    for (const [jobName, jobData] of Object.entries(config.jobs)) {
        const canSelect = !user || user.level >= jobData.minLevel;
        const statusIcon = canSelect ? '✅' : '🔒';
        
        embed.addFields({
            name: `${getJobEmoji(jobName)} ${jobName.charAt(0).toUpperCase() + jobName.slice(1)} ${statusIcon}`,
            value: `💰 Maaş: ${formatMoney(jobData.salary)}\n📈 Gereken Seviye: ${jobData.minLevel}\n📝 ${jobData.description}`,
            inline: true
        });
    }
    
    if (user) {
        embed.setFooter({ text: `Mevcut mesleğiniz: ${user.job} • Seviyeniz: ${user.level}` });
    }
    
    return message.reply({ embeds: [embed] });
}

/**
 * Meslek Seç
 */
async function meslekSec(message, args) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (!args[0]) {
        return message.reply({ embeds: [createErrorEmbed('Meslek Belirtilmedi', 'Kullanım: `!meslek-sec <meslek>`\nMeslekleri görmek için: `!meslekler`')] });
    }
    
    const jobName = args.join(' ').toLowerCase().trim();
    const jobData = config.jobs[jobName];
    
    if (!jobData) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Meslek', `"${jobName}" adında bir meslek bulunamadı.\nMeslekleri görmek için: \`!meslekler\``)] });
    }
    
    if (user.job === jobName) {
        return message.reply({ embeds: [createErrorEmbed('Aynı Meslek', `Zaten ${jobName} olarak çalışıyorsunuz.`)] });
    }
    
    if (user.level < jobData.minLevel) {
        return message.reply({ embeds: [createErrorEmbed('Seviye Yetersiz', `Bu meslek için seviye **${jobData.minLevel}** gerekiyor.\nMevcut seviyeniz: **${user.level}**`)] });
    }
    
    const oldJob = user.job;
    user.job = jobName;
    await user.save();
    
    const embed = createSuccessEmbed(
        'Meslek Değiştirildi!',
        `Artık **${jobName.charAt(0).toUpperCase() + jobName.slice(1)}** olarak çalışıyorsunuz!`
    )
    .addFields(
        { name: '📤 Eski Meslek', value: `${getJobEmoji(oldJob)} ${oldJob}`, inline: true },
        { name: '📥 Yeni Meslek', value: `${getJobEmoji(jobName)} ${jobName}`, inline: true },
        { name: '💰 Yeni Maaş', value: formatMoney(jobData.salary), inline: true }
    )
    .setFooter({ text: jobData.description });
    
    return message.reply({ embeds: [embed] });
}

/**
 * Maaş Al
 */
async function maasAl(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (user.accountStatus === 'frozen') {
        return message.reply({ embeds: [createErrorEmbed('Hesap Dondurulmuş', 'Hesabınız dondurulmuş durumda.')] });
    }
    
    if (user.job === 'işsiz') {
        return message.reply({ embeds: [createErrorEmbed('İşsizsiniz', 'Maaş almak için önce bir meslek seçmelisiniz.\n`!meslekler` ile meslekleri görün.')] });
    }
    
    // Cooldown kontrolü (24 saat)
    if (isOnCooldown(user.lastSalary, config.salary.cooldown)) {
        const remaining = getRemainingTime(user.lastSalary, config.salary.cooldown);
        return message.reply({ embeds: [createErrorEmbed('Maaş Günü Değil', `Sonraki maaşınızı alabilmek için **${formatDuration(remaining)}** beklemeniz gerekiyor.`)] });
    }
    
    const jobData = config.jobs[user.job];
    let salary = jobData.salary;
    
    // Temerrüt kesintisi
    let deduction = 0;
    if (user.defaulted) {
        deduction = Math.floor(salary * config.default.salaryDeduction);
        
        // Kesinti borca eklenir
        user.creditDebt -= deduction; // Borçtan düş
        if (user.creditDebt < 0) user.creditDebt = 0;
    }
    
    // Gelir vergisi
    const tax = Math.floor((salary - deduction) * config.taxes.income);
    const netSalary = salary - deduction - tax;
    
    // Güncelle
    user.balance += netSalary;
    user.lastSalary = new Date();
    user.stats.totalEarned += netSalary;
    user.addTransaction('salary', netSalary, `Maaş (Meslek: ${user.job})`);
    
    // XP
    await user.addXP(50, config);
    
    await user.save();
    
    const embed = new EmbedBuilder()
        .setColor(config.colors.gold)
        .setTitle(`${getJobEmoji(user.job)} Maaş Alındı!`)
        .setDescription(`**${user.job.charAt(0).toUpperCase() + user.job.slice(1)}** maaşınız yatırıldı.`)
        .addFields(
            { name: '💵 Brüt Maaş', value: formatMoney(salary), inline: true },
            { name: '📊 Gelir Vergisi (%10)', value: formatMoney(tax), inline: true }
        );
    
    if (deduction > 0) {
        embed.addFields(
            { name: '⚠️ Temerrüt Kesintisi (%30)', value: formatMoney(deduction), inline: true },
            { name: '📉 Kalan Borç', value: formatMoney(user.creditDebt), inline: true }
        );
    }
    
    embed.addFields(
        { name: '💰 Net Maaş', value: formatMoney(netSalary), inline: true },
        { name: '🏦 Yeni Bakiye', value: formatMoney(user.balance), inline: true },
        { name: '⏰ Sonraki Maaş', value: '24 saat sonra', inline: false }
    )
    .setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Meslek Bilgisi
 */
async function meslek(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    const jobData = config.jobs[user.job];
    
    // Sonraki maaş zamanı
    let nextSalary = 'Şimdi alabilirsiniz!';
    if (isOnCooldown(user.lastSalary, config.salary.cooldown)) {
        const remaining = getRemainingTime(user.lastSalary, config.salary.cooldown);
        nextSalary = formatDuration(remaining);
    }
    
    const embed = createBankEmbed('Meslek Bilgisi')
        .addFields(
            { name: `${getJobEmoji(user.job)} Mesleğiniz`, value: user.job.charAt(0).toUpperCase() + user.job.slice(1), inline: true },
            { name: '💰 Maaş', value: formatMoney(jobData.salary), inline: true },
            { name: '📈 Seviyeniz', value: user.level.toString(), inline: true },
            { name: '📝 Açıklama', value: jobData.description, inline: false },
            { name: '⏰ Sonraki Maaş', value: nextSalary, inline: false }
        );
    
    if (user.defaulted) {
        embed.addFields({
            name: '⚠️ Temerrüt Uyarısı',
            value: `Maaşınızdan %30 kesinti yapılacaktır.`,
            inline: false
        });
    }
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    calis,
    meslekler,
    meslekSec,
    maasAl,
    meslek
};
