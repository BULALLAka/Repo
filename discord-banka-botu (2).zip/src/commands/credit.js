/**
 * ========================================
 * KREDİ KOMUTLARI
 * ========================================
 * !kredi-cek, !kredi-ode, !kredi-durum, !kredi-notu
 */

const { EmbedBuilder } = require('discord.js');
const User = require('../models/User');
const config = require('../config/config');
const {
    formatMoney,
    formatPercent,
    formatDate,
    formatDuration,
    parseAmount,
    getCreditScoreRating,
    createSuccessEmbed,
    createErrorEmbed,
    createBankEmbed
} = require('../utils/helpers');

/**
 * Kredi Çek
 */
async function krediCek(message, args) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (user.accountStatus === 'frozen') {
        return message.reply({ embeds: [createErrorEmbed('Hesap Dondurulmuş', 'Hesabınız dondurulmuş durumda.')] });
    }
    
    if (user.defaulted) {
        return message.reply({ embeds: [createErrorEmbed('Temerrüt Durumu', 'Temerrüt durumundasınız. Önce mevcut borcunuzu ödeyin.\n`!temerrut-durum` ile durumunuzu görün.')] });
    }
    
    if (user.creditDebt > 0) {
        return message.reply({ embeds: [createErrorEmbed('Mevcut Borç', `Zaten ${formatMoney(user.creditDebt)} borcunuz var.\nÖnce mevcut borcunuzu ödeyin: \`!kredi-ode\``)] });
    }
    
    // Kredi notu kontrolü
    if (user.creditScore < config.credit.minCreditScore) {
        return message.reply({ embeds: [createErrorEmbed('Düşük Kredi Notu', `Kredi çekebilmek için en az **${config.credit.minCreditScore}** kredi notuna sahip olmalısınız.\nMevcut notunuz: **${user.creditScore}**`)] });
    }
    
    const creditLimit = user.getCreditLimit(config);
    const interestRate = user.getInterestRate(config);
    
    if (!args[0]) {
        const creditRating = getCreditScoreRating(user.creditScore);
        
        const embed = createBankEmbed('Kredi Bilgileri')
            .setDescription('Kredi çekerek anlık nakit ihtiyacınızı karşılayabilirsiniz.')
            .addFields(
                { name: '💳 Kredi Limitiniz', value: formatMoney(creditLimit), inline: true },
                { name: '📈 Faiz Oranı', value: formatPercent(interestRate), inline: true },
                { name: `${creditRating.emoji} Kredi Notunuz`, value: `${user.creditScore} (${creditRating.rating})`, inline: true },
                { name: '📅 Ödeme Süresi', value: `${config.credit.paymentPeriod} gün`, inline: true },
                { name: '⚠️ Gecikme Cezası', value: formatPercent(config.default.lateFee), inline: true },
                { name: '📊 Günlük Temerrüt Faizi', value: formatPercent(config.default.dailyInterest), inline: true }
            )
            .addFields({ name: '📋 Kullanım', value: '`!kredi-cek <miktar>`\nÖrnek: `!kredi-cek 10000`', inline: false })
            .setFooter({ text: '⚠️ Zamanında ödenmeyen krediler temerrüte düşer!' });
        
        return message.reply({ embeds: [embed] });
    }
    
    const amount = parseAmount(args[0], creditLimit);
    
    if (!amount || amount <= 0) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Miktar', 'Lütfen geçerli bir miktar girin.')] });
    }
    
    if (amount > creditLimit) {
        return message.reply({ embeds: [createErrorEmbed('Limit Aşıldı', `Kredi limitiniz: ${formatMoney(creditLimit)}\nTalep ettiğiniz: ${formatMoney(amount)}`)] });
    }
    
    // Kredi hesaplama
    const interest = Math.floor(amount * interestRate);
    const totalDebt = amount + interest;
    const dueDate = new Date(Date.now() + config.credit.paymentPeriod * 24 * 60 * 60 * 1000);
    
    // Kredi ver
    user.balance += amount;
    user.creditDebt = totalDebt;
    user.creditDueDate = dueDate;
    user.creditHistory.push({
        amount: totalDebt,
        date: new Date(),
        paid: false
    });
    user.stats.totalEarned += amount;
    user.addTransaction('credit', amount, `Kredi çekildi (Toplam borç: ${formatMoney(totalDebt)})`);
    
    await user.save();
    
    const embed = new EmbedBuilder()
        .setColor(config.colors.success)
        .setTitle('💳 Kredi Onaylandı!')
        .setDescription('Kredi tutarı hesabınıza yatırıldı.')
        .addFields(
            { name: '💰 Çekilen Tutar', value: formatMoney(amount), inline: true },
            { name: '📈 Faiz (%)', value: formatPercent(interestRate), inline: true },
            { name: '💵 Faiz Tutarı', value: formatMoney(interest), inline: true },
            { name: '💳 Toplam Borç', value: formatMoney(totalDebt), inline: true },
            { name: '📅 Son Ödeme', value: formatDate(dueDate), inline: true },
            { name: '⏰ Kalan Süre', value: `${config.credit.paymentPeriod} gün`, inline: true },
            { name: '🏦 Yeni Bakiye', value: formatMoney(user.balance), inline: false }
        )
        .setFooter({ text: '⚠️ Son ödeme tarihinden sonra temerrüt faizi işler!' })
        .setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Kredi Öde
 */
async function krediOde(message, args) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    if (user.creditDebt <= 0 && !user.restructure) {
        return message.reply({ embeds: [createErrorEmbed('Borç Yok', 'Ödemeniz gereken bir kredi borcunuz bulunmuyor.')] });
    }
    
    // Yapılandırılmış borç varsa
    if (user.restructure && user.restructure.status === 'active') {
        return message.reply({ embeds: [createErrorEmbed('Yapılandırılmış Borç', 'Yapılandırılmış borcunuz var. Taksit ödemesi için: `!taksit-ode`')] });
    }
    
    const amount = parseAmount(args[0], user.balance);
    
    if (!amount) {
        const embed = createBankEmbed('Kredi Ödeme')
            .setDescription('Kredi borcunuzu ödeyin.')
            .addFields(
                { name: '💳 Mevcut Borç', value: formatMoney(user.creditDebt), inline: true },
                { name: '📅 Son Ödeme', value: user.creditDueDate ? formatDate(user.creditDueDate) : 'Belirsiz', inline: true },
                { name: '🏦 Bakiyeniz', value: formatMoney(user.balance), inline: true }
            )
            .addFields({ name: '📋 Kullanım', value: '`!kredi-ode <miktar>` veya `!kredi-ode all`', inline: false });
        
        if (user.defaulted) {
            embed.addFields({ name: '⚠️ Temerrüt Durumu', value: `**${user.calculateDefaultDays()} gün** gecikmeli`, inline: false });
        }
        
        return message.reply({ embeds: [embed] });
    }
    
    if (amount <= 0) {
        return message.reply({ embeds: [createErrorEmbed('Geçersiz Miktar', 'Lütfen geçerli bir miktar girin.')] });
    }
    
    if (amount > user.balance) {
        return message.reply({ embeds: [createErrorEmbed('Yetersiz Bakiye', `Bakiyeniz: ${formatMoney(user.balance)}`)] });
    }
    
    const paymentAmount = Math.min(amount, user.creditDebt);
    const remainingDebt = user.creditDebt - paymentAmount;
    
    // Ödeme yap
    user.balance -= paymentAmount;
    user.creditDebt = remainingDebt;
    user.stats.creditsRepaid += paymentAmount;
    user.addTransaction('credit_payment', paymentAmount, `Kredi ödemesi (Kalan: ${formatMoney(remainingDebt)})`);
    
    // Borç bittiyse
    if (remainingDebt <= 0) {
        user.creditDebt = 0;
        user.creditDueDate = null;
        
        // Kredi notunu artır
        user.creditScore = Math.min(config.creditScore.max, user.creditScore + config.creditScore.paymentBonus);
        
        // Temerrüt durumunu kaldır
        if (user.defaulted) {
            user.defaulted = false;
            user.defaultStartDate = null;
            user.defaultDays = 0;
            user.defaultPenaltyApplied = false;
        }
        
        // Kredi geçmişini güncelle
        const lastCredit = user.creditHistory[user.creditHistory.length - 1];
        if (lastCredit && !lastCredit.paid) {
            lastCredit.paid = true;
            lastCredit.paidDate = new Date();
        }
    }
    
    // XP kazan
    await user.addXP(config.credit.xpGain, config);
    
    await user.save();
    
    const embed = new EmbedBuilder()
        .setColor(remainingDebt <= 0 ? config.colors.success : config.colors.info)
        .setTitle(remainingDebt <= 0 ? '✅ Borç Tamamen Ödendi!' : '💳 Ödeme Yapıldı')
        .addFields(
            { name: '💰 Ödenen Tutar', value: formatMoney(paymentAmount), inline: true },
            { name: '💳 Kalan Borç', value: formatMoney(remainingDebt), inline: true },
            { name: '🏦 Bakiyeniz', value: formatMoney(user.balance), inline: true }
        );
    
    if (remainingDebt <= 0) {
        embed.addFields(
            { name: '📊 Kredi Notu', value: `+${config.creditScore.paymentBonus} puan`, inline: true },
            { name: '⭐ Yeni Kredi Notu', value: user.creditScore.toString(), inline: true }
        );
        embed.setDescription('🎉 Tebrikler! Kredi borcunuzu tamamen ödediniz.');
    }
    
    embed.setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Kredi Durumu
 */
async function krediDurum(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    const creditLimit = user.getCreditLimit(config);
    const interestRate = user.getInterestRate(config);
    const creditRating = getCreditScoreRating(user.creditScore);
    
    const embed = new EmbedBuilder()
        .setColor(user.defaulted ? config.colors.error : config.colors.bank)
        .setTitle('💳 Kredi Durumunuz')
        .addFields(
            { name: `${creditRating.emoji} Kredi Notu`, value: `${user.creditScore} (${creditRating.rating})`, inline: true },
            { name: '💳 Kredi Limiti', value: formatMoney(creditLimit), inline: true },
            { name: '📈 Faiz Oranı', value: formatPercent(interestRate), inline: true }
        );
    
    if (user.creditDebt > 0) {
        const now = new Date();
        const isOverdue = user.creditDueDate && now > user.creditDueDate;
        
        embed.addFields(
            { name: '💰 Mevcut Borç', value: formatMoney(user.creditDebt), inline: true },
            { name: '📅 Son Ödeme', value: user.creditDueDate ? formatDate(user.creditDueDate) : 'Belirsiz', inline: true },
            { name: '⏰ Durum', value: isOverdue ? '⚠️ GECİKMİŞ' : '✅ Normal', inline: true }
        );
        
        if (user.defaulted) {
            const defaultDays = user.calculateDefaultDays();
            embed.addFields({
                name: '🚨 TEMERRÜT',
                value: `**${defaultDays} gün** gecikme\nGünlük %1 faiz işlemektedir.`,
                inline: false
            });
        }
    } else {
        embed.addFields({ name: '💰 Mevcut Borç', value: '✅ Borç yok', inline: false });
    }
    
    // Kredi geçmişi özeti
    const paidCredits = user.creditHistory.filter(c => c.paid).length;
    const totalCredits = user.creditHistory.length;
    
    if (totalCredits > 0) {
        embed.addFields({
            name: '📊 Kredi Geçmişi',
            value: `Toplam: ${totalCredits} kredi\nÖdenen: ${paidCredits}\nÖdeme Oranı: %${Math.round((paidCredits / totalCredits) * 100)}`,
            inline: false
        });
    }
    
    embed.setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

/**
 * Kredi Notu Detayı
 */
async function krediNotu(message) {
    const user = await User.findOne({ odUserId: message.author.id });
    
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Hesap Bulunamadı', 'Önce `!hesap-olustur` ile hesap açın.')] });
    }
    
    const creditRating = getCreditScoreRating(user.creditScore);
    const creditLimit = user.getCreditLimit(config);
    
    const embed = new EmbedBuilder()
        .setColor(creditRating.color)
        .setTitle(`${creditRating.emoji} Kredi Notu: ${user.creditScore}`)
        .setDescription(`**Değerlendirme: ${creditRating.rating}**`)
        .addFields(
            { name: '📊 Not Aralığı', value: `${config.creditScore.min} - ${config.creditScore.max}`, inline: true },
            { name: '💳 Kredi Limiti', value: formatMoney(creditLimit), inline: true },
            { name: '📈 Faiz Oranı', value: formatPercent(user.getInterestRate(config)), inline: true }
        )
        .addFields({
            name: '📋 Kredi Notu Nasıl Değişir?',
            value: 
                `✅ Kredi ödemesi: **+${config.creditScore.paymentBonus}** puan\n` +
                `✅ Fatura ödemesi: **+${config.creditScore.billPaymentBonus}** puan\n` +
                `❌ Gecikme: **-${config.creditScore.latePenalty}** puan\n` +
                `❌ Ödenmemiş fatura: **-${config.bills.unpaidPenalty}** puan`,
            inline: false
        })
        .addFields({
            name: '⭐ Değerlendirme Tablosu',
            value: 
                `🌟 1800+ Mükemmel\n` +
                `⭐ 1500-1799 Çok İyi\n` +
                `✅ 1200-1499 İyi\n` +
                `⚠️ 900-1199 Orta\n` +
                `🔶 600-899 Düşük\n` +
                `🔴 300-599 Kötü\n` +
                `💀 0-299 Çok Kötü`,
            inline: false
        })
        .setFooter({ text: 'Yüksek kredi notu = Daha fazla limit, daha düşük faiz' })
        .setTimestamp();
    
    return message.reply({ embeds: [embed] });
}

module.exports = {
    krediCek,
    krediOde,
    krediDurum,
    krediNotu
};
