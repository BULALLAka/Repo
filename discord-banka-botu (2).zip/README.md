# Discord Banka Botu

Global ekonomi sistemli, gelismis Discord banka botu. Node.js ve MongoDB ile calisir.

## Ozellikler

- Hesap yonetimi (IBAN ile)
- Para yatirma/cekme/transfer
- Vadeli hesap (7/14/30 gun)
- Kredi sistemi (dinamik faiz)
- Temerrut yonetimi
- Fatura sistemi
- Level/XP sistemi
- Admin paneli

## Kurulum

### 1. Gereksinimleri yukle

```bash
npm install
```

### 2. .env dosyasini olustur

```env
DISCORD_TOKEN=bot_tokeniniz
MONGODB_URI=mongodb://localhost:27017/banka-bot
ADMIN_USERNAME=ikashop1
```

### 3. Botu baslat

```bash
# Normal
npm start

# Gelistirme (nodemon)
npm run dev
```

## Komutlar

### Hesap

| Komut | Aciklama |
|-------|----------|
| `!hesap-olustur` | Yeni banka hesabi olusturur |
| `!para` / `!bakiye` | Hesap bilgilerini gosterir |
| `!hesap-bilgi` | Detayli hesap bilgileri |
| `!islemler` | Son islemleri listeler |

### Banka Islemleri

| Komut | Aciklama |
|-------|----------|
| `!yatir <miktar>` | Bankaya para yatirir |
| `!cek <miktar>` | Bankadan para ceker |
| `!transfer @kisi <miktar>` | Baska kullaniciya transfer |
| `!iban-transfer <IBAN> <miktar>` | IBAN ile transfer |

### Calisma

| Komut | Aciklama |
|-------|----------|
| `!calis` | Calisarak para kazanir |
| `!meslek-sec <meslek>` | Meslek secer |
| `!meslekler` | Tum meslekleri listeler |
| `!maas-al` | Gunluk maas alir |

### Vadeli Hesap

| Komut | Aciklama |
|-------|----------|
| `!vadeli-ac <miktar> <7\|14\|30>` | Vadeli hesap acar |
| `!vadeli-durum` | Vadeli hesap durumu |
| `!vadeli-boz` | Vadeli hesabi erken bozar |

### Kredi

| Komut | Aciklama |
|-------|----------|
| `!kredi-cek <miktar>` | Kredi ceker |
| `!kredi-ode <miktar>` | Kredi borcunu oder |
| `!kredi-durum` | Kredi durumunu gosterir |

### Fatura

| Komut | Aciklama |
|-------|----------|
| `!faturalar` | Bekleyen faturalari listeler |
| `!fatura-ode <tur>` | Fatura oder |
| `!tum-faturalar-ode` | Tum faturalari oder |

### Temerrut

| Komut | Aciklama |
|-------|----------|
| `!temerrut-durum` | Temerrut durumunu gosterir |
| `!borc-yapilandir` | Borcu yapilandirir |

### Lider Tablolari

| Komut | Aciklama |
|-------|----------|
| `!zenginler` | En zengin kullanicilar |
| `!en-cok-borc` | En borclu kullanicilar |
| `!en-iyi-not` | En yuksek kredi notlari |
| `!en-caliskan` | En cok calisanlar |

### Yardim

| Komut | Aciklama |
|-------|----------|
| `!yardim` | Ana yardim menusu |
| `!yardim <kategori>` | Kategori yardimi |
| `!komutlar` | Tum komutlar |

## Admin Komutlari

Sadece `ikashop1` kullanicisi kullanabilir.

| Komut | Aciklama |
|-------|----------|
| `!admin-panel` | Admin paneli |
| `!faiz-ayarla <tur> <oran>` | Faiz orani ayarlar |
| `!vergi-ayarla <tur> <oran>` | Vergi orani ayarlar |
| `!hesap-dondur @kisi` | Hesap dondurur |
| `!hesap-ac @kisi` | Hesap acar |
| `!borc-sil @kisi` | Borc siler |
| `!para-ekle @kisi <miktar>` | Para ekler |
| `!para-sil @kisi <miktar>` | Para siler |
| `!temerrut-kaldir @kisi` | Temerrut kaldirir |
| `!ekonomi-sifirla ONAYLA` | Ekonomiyi sifirlar |
| `!ekonomi-rapor` | Detayli ekonomi raporu |
| `!kullanici-bilgi @kisi` | Kullanici bilgilerini gosterir |
| `!not-ayarla @kisi <puan>` | Kredi notu ayarlar |
| `!limit-ayarla <tur> <miktar>` | Limit ayarlar |

## Meslekler

| Meslek | Maas | Calisma Kazanci |
|--------|------|-----------------|
| Issiz | 0 | 50-150 |
| Memur | 2,500 | 100-300 |
| Esnaf | 3,000 | 150-400 |
| Freelancer | 3,500 | 200-500 |
| Yazilimci | 5,000 | 300-700 |
| Bankaci | 6,000 | 350-800 |
| Yonetici | 8,000 | 500-1,000 |

## Temerrut Sistemi

| Gun | Durum | Cezalar |
|-----|-------|---------|
| 1-6 | Normal | %10 ceza, gunluk %1 faiz, %30 maas kesintisi |
| 7-13 | Agir | Transfer yasagi, yeni kredi yasagi |
| 14+ | Dondurma | Tum islemler yasakli |

## Dosya Yapisi

```
/
├── index.js              # Ana bot dosyasi
├── package.json          # Paket bilgileri
├── .env.example          # Ornek env dosyasi
├── README.md             # Bu dosya
└── src/
    ├── config/
    │   └── config.js     # Bot ayarlari
    ├── models/
    │   ├── User.js       # Kullanici modeli
    │   └── Settings.js   # Ayarlar modeli
    ├── commands/
    │   ├── account.js    # Hesap komutlari
    │   ├── banking.js    # Banka komutlari
    │   ├── work.js       # Calisma komutlari
    │   ├── savings.js    # Vadeli hesap komutlari
    │   ├── credit.js     # Kredi komutlari
    │   ├── default.js    # Temerrut komutlari
    │   ├── bills.js      # Fatura komutlari
    │   ├── leaderboard.js # Lider tablolari
    │   ├── admin.js      # Admin komutlari
    │   └── help.js       # Yardim komutlari
    └── utils/
        ├── helpers.js    # Yardimci fonksiyonlar
        └── scheduler.js  # Zamanlanmis gorevler
```

## Lisans

MIT
